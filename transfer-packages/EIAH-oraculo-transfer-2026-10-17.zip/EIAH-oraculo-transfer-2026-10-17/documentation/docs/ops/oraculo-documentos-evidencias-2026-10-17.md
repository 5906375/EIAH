# Oráculo SC — documentos vinculados à preparação

> Evolução: a conferência documental assistida já pode registrar leitura e comparar dados com a referência salva; veja [conferência e correspondência](oraculo-conferencia-documental-2026-10-17.md). O registro abaixo preserva o corte anterior de vínculo e integridade.

Data: 2026-10-17. Status: **vínculo e integridade técnica evidenciados localmente; revisão documental e operação permanecem parciais**.

## Fluxo do usuário

Front Door EIAH → cockpit Oráculo SC → preparação salva → documentos e evidências → enviar e vincular → reabrir, verificar integridade e baixar → revisão do conteúdo pendente.

O usuário escolhe o tipo (instrução de devolução, agendamento, vistoria/foto, recebimento/EIR, comunicação ou outro), descreve a origem e pode informar a data do documento. O arquivo é enviado pelo upload existente e associado ao caso salvo. Alterações locais do contexto precisam ser salvas antes de vincular um documento, para evitar perda silenciosa da edição.

A lista distingue **arquivo disponível e íntegro**, **arquivo indisponível**, **registro não encontrado** e **integridade divergente**. O conteúdo continua **não revisado** em todos os casos. A tela mostra origem declarada, data declarada, responsável pelo vínculo, horário e hash. O botão de download do caso exige nova validação no servidor; não usa URL pública do storage.

## Estrutura reutilizada

- `POST /api/uploads` e `GET /api/uploads/:id`, `UploadedDocument`, `persistBuffer`/`loadStoredObject` e os providers existentes do core.
- Padrão de associação de documentos do IMOB, respeitando a diferença entre registro de documento e validação de conteúdo. Não altera os fluxos de dados, CRM ou contrato do IMOB.
- `GovernedCase` e `GovernedCaseRevision`: vínculo registrado como revisão do mesmo caso Oráculo, sem tabelas ou migrations novas.
- Sessão e políticas já conectadas à Logística. Nenhum agente ou grant automático é criado. `oraculo-sc` é a classificação do upload no campo existente `agentSlug`.

## Contrato e autorização

O cliente envia apenas `{documentId, kind, sourceDescription, documentDate?, expectedRevision}`. Hash, nome, MIME, tamanho, data de upload e responsável pelo vínculo vêm do servidor. Claims de `sha256`, `linkedBy`, aprovação ou autoridade no payload são rejeitados.

Só podem ser vinculados uploads `oraculo-sc` do tenant/workspace autenticado. O storage key também precisa corresponder ao mesmo escopo. Acesso a documentos de IMOB ou outro agente não é presumido a partir do acesso logístico.

Upload e vínculo exigem contexto logístico permitido, uso fora do modo somente leitura e política exata `log.oraculo_preparation.write`. Consulta e download exigem o contexto logístico. Tokens sem usuário não acessam arquivos Oráculo. Revogação somente leitura preserva consulta e download; bloqueio total impede ambos, incluindo acesso pelo endpoint genérico de upload.

A instalação não concede essas políticas. Nenhuma liberação real foi configurada nesta tarefa.

## Rotas

| Método e rota | Função |
| --- | --- |
| `POST /api/uploads?agentSlug=oraculo-sc` | Upload autenticado pelo pipeline existente. |
| `POST /api/logistica/oraculo/preparations/:id/evidence` | Vincula um upload ao caso e cria revisão, com comparação de `expectedRevision`. |
| `GET /api/logistica/oraculo/preparations/:id/evidence` | Revalida metadados e bytes; retorna integridade técnica, conteúdo/validação operacional não realizados. |
| `GET /api/logistica/oraculo/preparations/:id/evidence/:documentId/file` | Download autenticado, condicionado ao hash e aos metadados registrados no vínculo. |
| `GET /api/logistica/oraculo/preparations/:id/revisions` | Histórico existente, incluindo quantidade de documentos em cada revisão. |

## Integridade e histórico

O hash SHA-256 do arquivo é calculado a partir dos bytes lidos do storage no momento do vínculo. Mudança posterior dos bytes, metadados divergentes, falta do arquivo ou remoção do registro bloqueiam o download pelo caso. O documento é marcado `unreviewed`, nunca como aprovado.

A associação é incluída no snapshot canônico do caso e gravada com sua revisão numa transação. Edições futuras de contexto preservam os vínculos. Duplicar o mesmo documentId no mesmo caso é recusado. Limite: 20 vínculos por caso. Não há remoção/edição de vínculo nem alteração de revisão passada por estas rotas.

Snapshots históricos sem o campo opcional `evidences` mantêm seu hash original: o contrato não injeta default durante a leitura. A compatibilidade foi exercitada com snapshots persistidos, reabertura, vínculo e histórico.

## Limites materiais

- Hash do arquivo comprova correspondência com os bytes registrados no vínculo; não é assinatura do emissor nem prova de autenticidade.
- Origem e data do documento são declarações do usuário. O responsável registrado é quem vinculou o arquivo, não uma identificação comprovada de seu emissor ou do primeiro uploader.
- Não há OCR, extração/comparação de número do contêiner, conferência da operação, avaliação legal ou decisão humana de aceite nesta entrega. Ter um EIR anexado não encerra automaticamente responsabilidade ou custos.
- O caso continua em `DISCOVERY`, sem execução, pagamento ou transmissão externa. Pré-DUIMP mantém seu gate próprio.
- Upload e vínculo são duas etapas. Um upload aceito pode ficar sem vínculo após conflito/falha. A UI conserva o ID para repetir o vínculo sem reenviar o mesmo arquivo enquanto a tela permanece aberta. Falhas ambíguas exigem atualizar e conferir o caso; não há idempotência global de upload.
- Limites de tamanho/MIME são os existentes do core (por padrão 5 MB por arquivo; a UI envia um arquivo por vez). Não foi introduzida detecção de conteúdo, antivírus, limpeza ou política de retenção nova. O job existente de retenção é limitado a `imob-intake`.
- Validação local com provider local; durabilidade/configuração de storage em produção e publicação não foram comprovadas.

## Validação executada

Evidências: `ops/evidence/latest/oraculo-evidence-case-local-2026-10-17/`.

- 17 testes HTTP/PostgreSQL (incluindo o teste pai) aprovados: core, persistência, revisão, upload, permissão separada, payload forjado, isolamento, bytes alterados com mesmo tamanho, arquivo/registro ausentes, legado sem campo novo, somente leitura e bloqueio total.
- 30 regressões de documentos IMOB, providers, upload pelo servidor e retenção aprovadas. A primeira invocação dessa suite apontou para um banco de setup vazio; falhou por tabela ausente e foi encerrada. A reexecução no banco dedicado passou; ambos os logs estão preservados.
- 6 testes API puros e 58 frontend aprovados; 86 testes Oráculo/contratos aprovados.
- Build de contratos, build web e typecheck API aprovados. Typecheck web mantém os mesmos 62 diagnósticos normalizados de HEAD.
- Chromium com routers HTTP reais, PostgreSQL e arquivos locais: criar preparação, anexar, conferir hash, baixar bytes originais, recarregar/reabrir, histórico, proteção da edição não salva e viewport mobile. Tráfego fora de loopback bloqueado no teste. Sessão sintética; cadastro/login real e bootstrap completo da aplicação não são comprovados pelo harness. A regressão de upload existente exercitou a rota no servidor completo.

Nenhum domínio ou configuração de rede foi alterado. Sem commit, push, CI remoto ou deploy.

Próxima lacuna: revisão do conteúdo e correspondência dos documentos com a operação concreta, com responsáveis e critérios de aceite definidos no contexto do cenário. Não se presume cobertura legal integral.

Agente envolvido: Codex, sem subagentes.
