# Profile — alinhamento de contrato e exportações, Etapa 12, 17/10/2026

Escopo autorizado: alinhar contrato, Profile e exportações; sem implementar o produtor dos indicadores.

## Resultado

O typecheck web passou de 21 diagnósticos para zero, sem casts para esconder incompatibilidades. A cobertura usa a unidade “Interações registradas”, campos de contagem por Events e timeseries[].date. Não houve alteração de backend, persistência, engine ou contrato de rastreabilidade nesta etapa.

```mermaid
flowchart TB
  A["Contrato do cliente<br/>interações, date, UTC, qualidade e valores ausentes"] --> B["Validar disponibilidade<br/>sem calcular agregações ou percentuais"]
  B --> C["Profile"]
  B --> D["JSON existente"]
  B --> E["CSV"]
  B --> F["Impressão"]
  G["Produtor da API<br/>ainda pendente"] -.-> A
```

## Contrato e comportamento

| Antes | Agora |
| --- | --- |
| Tela esperava totalSessions/contractSessions/fallbackSessions | Cobertura consome totalEvents/contractEvents/fallbackEvents |
| unknownSourceSessions não existia no tipo | unknownSourceEvents representa contagem ou ausência; não recebe zero por padrão |
| Sem contagem líquida/fallback desconhecido | netContractEvents e unknownFallbackEvents seguem a definição da Etapa 10 |
| bucketStart na tela/CSV, date no cliente | date padronizado; CSV separa o bucket do intervalo solicitado |
| Nome de workspace presumido | workspaceName é opcional; fallback para workspaceId, sem consulta ou join novo |
| Percentuais obrigatoriamente numéricos | Percentuais e contagens podem ser null quando indisponíveis |
| Origem implícita no rótulo source=tutor_contract_v1 | Estado da medição e assurance explícitos; rótulo não certifica a origem |

measurement declara unidade registered_interaction, status complete/incomplete/empty/unavailable, assurance server_verified/client_reported/unavailable e motivo opcional representado por null. O recorte declara UTC, compatível com as datas ISO já geradas no Profile.

A normalização no cliente faz verificações de disponibilidade e coerência básica das contagens. Não soma registros, calcula taxas ou implementa o produtor. Exige recorte UTC confirmado; um payload incompatível vira erro específico da cobertura e não descarta o histórico.

Para client_reported, a marca permanece visível e exportada, mas contagens de classificação e percentuais ficam indisponíveis, pois não equivalem a comprovação independente. O total de interações fornecido pode continuar disponível. Um período explicitamente vazio preserva zeros fornecidos e deixa os percentuais indisponíveis. Ausência, unidade desconhecida ou medição indisponível não geram zeros.

Taxas fornecidas só podem aparecer com consulta completa, unidade válida, declaração de verificação pelo servidor, total positivo e dados pertinentes disponíveis. Origem desconhecida bloqueia cobertura contratual/líquida; fallback desconhecido bloqueia fallback/líquida. Consulta incompleta bloqueia taxas. Uma taxa zero válida em população não vazia continua sendo 0%.

**Limite:** server_verified é uma declaração esperada do futuro produtor autenticado. Esta etapa não fornece essa comprovação nem promove rastreios client_reported a verificados. Os exemplos verificados nos testes são sintéticos.

## Exportações

- JSON: conserva o histórico existente e inclui a cobertura normalizada, com nulls e qualidade explícita.
- CSV: inclui unidade, status, assurance, motivo, UTC, contagens e percentuais; célula vazia significa indisponível, enquanto zero fornecido permanece zero. A série usa date para o início nominal do bucket e mantém dateFrom/dateTo como janela solicitada.
- Impressão: usa os mesmos formatadores da tela, informa qualidade/UTC e apresenta “Indisponível”, sem null% ou undefined%. Motivos e datas da cobertura são escapados para HTML.
- O campo legado totalSessions do export de histórico permanece no payload/API existente por compatibilidade; seu rótulo visual passa a registros/interações. Ele não é convertido em contagem de cobertura nem tratado como conversas únicas.
- A independência do histórico introduzida na Etapa 9 foi preservada. A regra existente de habilitação do CSV, que exige histórico e cobertura carregados, permanece.

## Arquivos desta etapa

- apps/web/src/lib/api.ts — contrato da resposta de cobertura e normalização da consulta existente.
- apps/web/src/features/profile/helpdeskCoverage.ts — verificações de disponibilidade, formatação e CSV compartilhados.
- apps/web/src/features/profile/helpdeskCoverage.test.ts — casos de disponibilidade, comprovação, contagens e exportação.
- apps/web/src/pages/profile.tsx — campos, rótulos, estados e exportações alinhados.

Os ajustes anteriores do workspace foram preservados. Relatório, evidências e índice também foram registrados.

## Validação e limites

Evidências: ops/evidence/latest/profile-coverage-alignment-stage12-2026-10-17/.

- Typecheck web: aprovado, 21 → 0 diagnósticos.
- Build web: aprovado.
- Cinco testes de normalização/exportação: aprovados.
- Quatro cenários Chromium: aprovados com identidade/API sintéticas, downloads reais JSON/CSV e impressão stub. Cobrem números completos fornecidos, client_reported, vazio e erro de cobertura com histórico preservado. Não houve gravação de backend.
- Comandos e hashes estão em results.json; índice de evidências validado separadamente.

Nenhum endpoint produtor, cálculo de indicadores, migração, política de acesso, validação independente de origem ou avaliador LLM foi implementado. Não houve commit ou deploy. Sem subagentes.

Status: alinhamento de frontend evidenciado; medição operacional e produtor da API continuam pendentes.
