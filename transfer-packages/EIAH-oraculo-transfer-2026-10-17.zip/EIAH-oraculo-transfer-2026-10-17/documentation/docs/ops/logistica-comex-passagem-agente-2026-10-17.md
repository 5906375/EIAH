# Passagem de contexto — Logística & Comex / Oráculo SC / Pré-DUIMP

Data de referência: 17/10/2026.
Destinatário: agente que continuará a investigação no VS Code, incluindo Claude Code.
Natureza: resumo de continuidade com referências às evidências existentes; não autoriza implementação ou publicação.

## 1. Leia primeiro

Antes de investigar ou executar, leia `CLAUDE.md` e siga suas instruções, incluindo arquivos aplicáveis aos subdiretórios. Depois consulte as fontes exigidas: `IA_EIAH.md`, `AGENTS.md`, `ROADMAP_UNIFICADO_v8_ATUALIZADO_2026-06-15.md`, `docs/architecture/agent-chat-runtime.md` e `docs/EVIDENCE_INDEX.md`.

Este resumo não substitui as fontes normativas nem concede autorização adicional. Se alguma fonte obrigatória estiver ausente, registre e siga o procedimento do repositório.

## 2. Objetivo e decisões do usuário

Construir e validar a base integrada da experiência de Logística & Comex, com Oráculo SC e o recorte Pré-DUIMP, reutilizando os mecanismos existentes do EIAH.

- Toda entrada e saída deve passar pelo Front Door EIAH.
- O cockpit pode ter navegação própria, integrado ao Front Door, com contexto e retorno preservados.
- Sempre consultar e reutilizar o Core e o IMOB, vertical mais madura, antes de propor estruturas novas; respeitar o contexto de cada vertical.
- A demo `https://oraculosc.vercel.app/` é referência solicitada para o frontend. A intenção é mapear a demo inteira, comparar com o IMOB e delimitar o corte. Não presumir equivalência integral já implementada.
- Primeiro cenário operacional escolhido: devolução de contêiner vazio. Porto, depósito e fluxo podem permanecer em aberto como opções para o usuário informar; exigir dados quando necessários à operação.
- O usuário exige explicação e autorização por etapa antes de corrigir ou ampliar o escopo. Não reutilizar autorizações antigas como autorização geral.
- Arquitetura do chat: agente define, engine executa, launcher renderiza. Não criar lógica cognitiva no `ChatAgentLauncher`.

Terminologia: o usuário utiliza “Logística & Comex”. No roadmap, a vertical pública é `Logística`; Comex/DUIMP é recorte interno. Pré-DUIMP é preparação técnica com gates próprios, sem significar liberação operacional, pilot ou produção. Consultar especialmente a seção 15 do roadmap.

## 3. Estrutura da experiência

```mermaid
flowchart TD
    A[Core EIAH: identidade, workspace e autorização]
    B[Front Door: Chat canônico]
    C[Logística: cockpit Oráculo SC]
    D[Preparações, documentos e conferências]
    E[Pré-DUIMP: gates próprios]
    A --> B --> C --> D
    C --> E
    C -->|Retorno com domínio Logística| B
```

Não assumir que a existência de uma rota ou módulo equivale a produto operacional liberado.

## 4. Base implementada e validada localmente

| Área | Estado demonstrado no recorte local |
| --- | --- |
| Core | Fluxos existentes de solicitação, decisão, ativação e sessão reutilizados; ativação não concede políticas automaticamente |
| Front Door e cockpit | Menu abre `/app/logistica`; retorno aponta para `/app/chat?domain=logistica` |
| Preparações | Persistência governada, reabertura, revisões, controle de concorrência e integridade |
| Documentos | Upload existente, vínculo ao caso, hash dos bytes no servidor e download autenticado |
| Conferência | Transcrição humana, identificação do revisor, comparação de campos e histórico |
| Mudança de contexto | Conferência anterior perde a correspondência atual; nova leitura pode registrar divergência sem apagar histórico |
| Acesso | Isolamento de workspace, políticas específicas, somente leitura e revogação verificados |
| Pré-DUIMP | Mantém liberação própria; acesso ao Oráculo não o libera automaticamente |

O cockpit continua limitado a preparação/contexto. Execução operacional e transmissão externa não foram liberadas nesta frente.

## 5. Última autorização executada e resultados

Autorização expressa do usuário:

> Autorizo somente essa validação integrada do Oráculo SC, com dados sintéticos e sem corrigir código, conceder permissões reais ou publicar.

Resultados registrados, não reexecutados para produzir este resumo:

| Verificação | Resultado |
| --- | --- |
| `pnpm test:logistica-core:integration` | 18 cenários + teste pai aprovados, 0 falhas |
| `pnpm test:logistica-core` | 6 + 58 = 64 testes aprovados, 0 falhas |
| Navegador Chromium | 9 verificações aprovadas com routers reais, PostgreSQL e storage locais |
| Typecheck web | 0 erros, código de saída 0 |
| Preservação de fontes | 1.249 arquivos comparados, nenhum alterado naquela validação |
| Evidence Index | Check aprovado, 686 referências conferidas naquela execução |

O navegador comprovou login com senha sintética, entrada pelo menu do Front Door, criação de preparação, upload/download, registro da conferência, recuperação após recarregar, alteração de contexto, histórico e retorno ao Front Door. Verificou também ausência de liberação automática do Pré-DUIMP.

O primeiro ensaio do helper de navegador falhou por ambiguidade entre botões “Entrar”. Somente o helper foi ajustado; a falha foi preservada e a execução final passou. Não houve correção de código de aplicação nessa validação.

### Limites da comprovação

- Foi usado um servidor local com routers reais selecionados, não o bootstrap completo da API de produção.
- Aprovação, ativação e revogação foram testadas pela API, não pelas telas administrativas.
- O navegador utilizou workspace sintético ativado pela suíte HTTP; não foi uma jornada única de provisionamento integral pela interface.
- Não foram demonstradas operação com depósito real, agendamento, extração automática de documento, cobertura integral da legislação ou transmissão ao Portal Único/Siscomex.
- Anexar ou conferir EIR não comprova autenticidade, aceite da devolução, fim da responsabilidade ou encerramento de cobranças.
- Banco local reteve fixtures sintéticas. Servidores iniciados na última validação foram encerrados; não presumir que processos ou credenciais continuam disponíveis.
- Nenhuma permissão real, deploy ou publicação foi realizada nessa etapa.

## 6. Evidências a transportar ou consultar

Todos os caminhos abaixo são relativos à raiz do repositório:

- Relatório: `docs/ops/oraculo-base-validacao-integrada-2026-10-17.md`.
- Pasta da execução: `ops/evidence/latest/oraculo-integrated-base-validation-2026-10-17/`.
- Manifesto: `results.json` nessa pasta.
- Logs: `http-integration.log`, `core-interface.log`, `browser.log`, `web-typecheck.log`, `evidence-index-check.log`.
- Resultados do navegador: `browser-results.json`.
- Preservação de fontes: `source-preservation.json`.
- Capturas: `review-desktop.png` e `review-mobile.png`. São do painel de conferência, não do cockpit inteiro.
- Ensaio inicial malsucedido: `browser-attempt1.log`.
- Helpers: `ui-server.ts` e `browser-check.mjs`. Não executar sem conferir banco dedicado e instruções aplicáveis; não copiar credenciais privadas.
- Contexto anterior: `docs/ops/logistica-base-retomada-2026-10-17.md`, `docs/ops/oraculo-jornada-acesso-core-2026-10-16.md`, `docs/ops/oraculo-persistencia-preparacao-2026-10-17.md`, `docs/ops/oraculo-documentos-evidencias-2026-10-17.md`, `docs/ops/oraculo-conferencia-documental-2026-10-17.md`.

As capturas não carregaram para o usuário nesta interface de conversa. Não afirmar que ele conseguiu vê-las. No VS Code, abrir os arquivos diretamente se estiverem presentes.

## 7. Rotas e fontes para investigação

### Interface

| Função | Rota |
| --- | --- |
| Login | `/access` |
| Front Door de Logística | `/app/chat?domain=logistica` |
| Cockpit Oráculo SC | `/app/logistica` |
| Pré-DUIMP | `/app/logistica/pre-duimp` |

### API

| Função | Método e rota |
| --- | --- |
| Login | `POST /api/auth/login` |
| Solicitar liberação | `POST /api/vertical-access/request` |
| Decisão de aprovação | `POST /api/admin/vertical-approvals/:id/decision` |
| Prévia e confirmação da ativação | `POST /api/chat/vertical-activation/preview` e `POST /api/chat/vertical-activation/confirm` |
| Contexto de sessão | `GET /api/session/context?domain=logistica` |
| Preparações | `GET/POST /api/logistica/oraculo/preparations` |
| Abrir/atualizar | `GET/PATCH /api/logistica/oraculo/preparations/:id` |
| Histórico | `GET /api/logistica/oraculo/preparations/:id/revisions` |
| Upload | `POST /api/uploads?agentSlug=oraculo-sc` |
| Evidências | `GET/POST /api/logistica/oraculo/preparations/:id/evidence` |
| Download vinculado | `GET /api/logistica/oraculo/preparations/:id/evidence/:documentId/file` |
| Conferências | `GET/POST /api/logistica/oraculo/preparations/:id/document-reviews` |

Fontes principais: `apps/web/vite.config.ts`, `apps/web/src/lib/api.ts`, `apps/web/src/App.tsx`, `apps/web/src/pages/access.tsx`, `apps/web/src/pages/app/logistica/cockpit.tsx`, `apps/web/src/features/logistica/`, `apps/api/src/index.ts`, `apps/api/src/routes/auth.ts`, `session.ts`, `oraculoPreparation.ts`, `uploads.ts`, `verticalAccess.ts`, `chatVerticals.ts`, `marketplace.ts` e `apps/api/src/tests/logistica-core.integration.test.ts`.

## 8. Trabalho atual: preparar teste manual no VS Code com API Render

O usuário pediu um prompt para outro agente consultar o código no VS Code e a API Render. Ainda não foi apresentada evidência dessa investigação externa.

O próximo agente deve primeiro investigar, sem alterar código/configuração, instalar, iniciar serviços, criar usuários, conceder permissões, migrar ou publicar. Consultas de conectividade devem ser sem escrita. Propor a próxima ação concreta e aguardar autorização antes de executá-la.

Checklist da investigação:

1. Ler `CLAUDE.md` antes de tudo e cumprir as instruções aplicáveis.
2. Identificar branch, commit e alterações locais; preservar todas.
3. Confirmar se a cópia do VS Code contém os arquivos e alterações deste trabalho. Este resumo sozinho não transfere código.
4. Localizar scripts existentes e uso efetivo de `VITE_API_URL`, `VITE_API_PROXY_TARGET` e proxy `/api`.
5. Identificar a URL/serviço da API Render pela configuração disponível. Se faltar, pedir URL ou nome do serviço, nunca segredos.
6. Verificar saúde documentada, CORS/CSP, versão implantada e registro das rotas no bootstrap, sem escrita.
7. Separar rota encontrada no código, registrada no servidor e comprovadamente disponível no Render. Um 401/403 isolado não comprova a integração completa.
8. Confirmar ambiente e workspace de teste isolados. Não presumir homologação nem realizar escritas em produção.
9. Conferir persistência/storage no Render pelas configurações e evidências disponíveis.
10. Entregar diagnóstico, mapa de conexão, bloqueios e comando proposto para iniciar o frontend; pedir autorização para a próxima etapa.

Não há URL Render confirmada neste resumo. Não inventar endereço ou afirmar sincronização/deploy.

### Roteiro manual proposto, após aprovação dos pré-requisitos

Login → confirmar workspace de teste → Front Door → menu Logística & Comex → cockpit Oráculo SC → salvar preparação sintética → sair e reabrir → anexar documento sintético → baixar e conferir → registrar leitura → consultar histórico → voltar ao Front Door.

```mermaid
flowchart LR
    A[VS Code: cópia local] --> B[Frontend no navegador]
    B --> C[API Render: versão a conferir]
    C --> D[Identidade e workspace de teste]
    C --> E[Persistência e storage a conferir]
```

## 9. Frentes encerradas ou adiadas

- Ciclo de correção do typecheck web encerrado com zero erros nas execuções documentadas. Não presumir que o resultado vale para outra cópia ou commit sem verificar.
- Ajuste isolado autorizado no teste de menu Pré-DUIMP incluiu a rota existente `/app/logistica`; suíte passou de 34/35 para 35/35, preservando Chat canônico e gates.
- Etapa 12 alinhou contrato, Profile e exportações; não implementou o produtor dos indicadores.
- Etapa 13 dos indicadores de Profile permanece adiada por decisão do usuário.
- Validação integrada própria do Pré-DUIMP continua candidata a etapa posterior; não está automaticamente autorizada por este documento.

## 10. Baseline e precauções de continuidade

Na execução local documentada: checkout `/workspace/EIAH`, branch `work`, HEAD `5c4a9b287addf5b7a622ddf63729a75d1e8f508f`, com muitas alterações locais e arquivos não rastreados de etapas anteriores. O HEAD sozinho não identifica a implementação validada; consultar manifesto e evidências e comparar a árvore.

Não executar reset, clean, descarte de alterações, commit, push, deploy ou migração por inferência. Não transportar tokens, senhas, arquivos de credenciais ou URLs de banco com segredos. Se for necessário sincronizar as cópias, apresentar primeiro o que está faltando e a forma proposta de transferência para aprovação.

Agente responsável por esta passagem: Codex. Sem subagentes nesta tarefa. Este documento consolida resultados existentes; não registra nova execução funcional nem promove a vertical a operacional.
