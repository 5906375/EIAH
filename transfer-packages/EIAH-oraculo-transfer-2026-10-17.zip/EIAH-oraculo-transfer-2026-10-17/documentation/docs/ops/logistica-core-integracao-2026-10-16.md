# Logística — liberação, ativação e sessão pelo core EIAH

Data: 16/10/2026. Status: **parcial** para produto; integração de acesso
evidenciada no escopo dos testes locais abaixo. Agente: Codex, sem subagentes.
Baseline `5c4a9b2`, com alterações locais identificadas pelos hashes da evidência.

## Problema e comportamento entregue

As rotas de liberação, ativação e sessão aceitavam apenas IMOB. LOGISTICA
agora usa as mesmas rotas, serviço transacional, administrador da plataforma,
cadastro, login, convite, perfis e workspace existentes. Não há outro sistema
de contas nem outro backend de ativação.

Identidades distintas preservadas: produto `LOGISTICA`; vertical de chat
`log` (já existente no contrato); domínio de sessão `logistica`. O nome
apresentado é Logística & Comex. O Oráculo continua cockpit/produto e a
Pré-DUIMP seu módulo, sem ativação independente inventada.

No Front Door, o pedido “ativar Logística” usa o engine de ativação existente:
preview → confirmação explícita “Confirmar ativação de Logística” → serviço
de ativação. Sem liberação, a proposta oferece “Pedir liberação de Logística”.
O pedido usa a fila existente, com score somente consultivo e decisão humana
pelo administrador EIAH. Confirmação de IMOB não confirma uma proposta LOG.

## Reaproveitamento e fronteiras

- `verticalAccess.ts` e `verticalAccessApproval.ts`: mesmos pedido, decisão,
  auditoria e revogação por tenant/workspace/vertical.
- `productActivation.ts`: mesma instalação e transação de provisionamento;
  catálogos existentes foram versionados em 2. LOGISTICA provisiona apenas
  EIAH, sem agente operacional novo e sem políticas automáticas.
- `platformAccess.ts`: enum compartilhado de produtos e domínio, com tipos
  reutilizados nos catálogos. Nenhuma dependência ou lockfile foi alterado.
- `verticalActivationEngine.ts`: mesmo caminho de conversa e confirmação;
  launcher não recebeu regra cognitiva nova.
- `session.ts`, sessionStore e sessionContextSync: contexto projetado pelo
  servidor, identidade existente e invalidação local ao mudar escopo/token.
  Falha de atualização logística remove acesso local anterior. Respostas
  atrasadas continuam sujeitas à sincronização existente.

## Instalação não concede uso

A capability `logisticaContext` é estritamente `context_only`, com
`executionAllowed=false` e `externalTransmissionAllowed=false`.

Para expor o domínio logístico, o servidor exige em conjunto:

1. Identidade de usuário e membership ativa no tenant/workspace exato.
2. Instalação `LOGISTICA` com status literal `active`.
3. Liberação EIAH aplicável: aprovada, ou uso atual preservado conforme o
   modo de revogação existente; bloqueio total sempre nega.
4. Política explícita `log.context.read` no workspace exato, resolvida pelo
   TenantPolicyStore existente. Grant tenant-wide não substitui essa política.

Essa política de contexto aplica-se aos membros ativos daquele workspace;
não constitui aprovação de uma operação ou competência de revisor. Ela não
é criada pela instalação. Sua concessão permanece um ato administrativo
explícito no mecanismo de políticas existente. Não foram configurados grants,
usuários ou liberações reais durante esta tarefa.

Liberação ausente/pendente/recusada não recebe o fallback permissivo de uso
legado. Instalação de outro escopo/produto, membership inativa, política
ausente/negada, falha de leitura ou token revogado não libera contexto.
Solicitar explicitamente um domínio logístico negado retorna 403; a sessão
core omite esse domínio dos disponíveis. Negações são auditadas pelo core.

Revogação `somente_leitura` preserva contexto de leitura; `sem_nova_ativacao`
preserva uso existente; `bloqueio_total` retira o domínio. Nova ativação exige
status aprovado, como no serviço existente. Nenhuma dessas condições permite
gate, pagamento, compartilhamento externo, integração portuária ou Siscomex.

## Validação local

Evidências: `ops/evidence/latest/logistica-core-access-local-2026-10-16/`.

- `pnpm test:logistica-core`: testes puros de autorização e regressões dos
  engines Front Door/sessão, incluindo seleção logística, confirmação, pedido
  e invalidação de contexto. Logs distinguem os dois runners, sem somar
  novamente testes já cobertos nas regressões anteriores.
- `pnpm test:logistica-core:integration`: sete testes (inclui o teste pai)
  aprovados em PostgreSQL local isolado. Exercita HTTP de pedido, administrador
  distinto do Founder, ativação confirmada, ausência de grants automáticos,
  política explícita, workspace diferente, membership inativa, política
  revogada, modos de revogação e token revogado.
- Regressões selecionadas de provisionamento/agentes/experiência: 39 aprovados.
- Typecheck da API e build web passaram. Typecheck web completo permanece
  falho com 62 erros, com diagnósticos normalizados iguais aos de HEAD; o
  comparativo foi executado preservando os arquivos de trabalho byte a byte.
- O checker de testes órfãos passou, sem novos testes bloqueantes.

O banco local dedicado foi criado no PostgreSQL/pgvector instalado nesta
nuvem, com nome `eiah_logistica_core_20261016`. Preparação por `prisma db push`
do schema atual e extensão vector, não pelo histórico completo de migrations.
Fixtures são sintéticas. O teste integrado recusa outros nomes de banco.
O client Prisma foi gerado com verificação TLS/checksum preservada; os
artefatos gerados versionados foram restaurados aos bytes anteriores.

O job `LogisticaCoreAccess` foi adicionado ao workflow existente com banco
efêmero próprio e Redis. Executa os mesmos scripts, sem aprovar sozinho
qualquer workspace. A execução no GitHub Actions ainda não ocorreu nesta
tarefa; validação local não é publicação nem deploy.

## Limites e próximo passo

Não há cockpit de sete telas entregue neste corte. O domínio retorna ao
Front Door e expõe contexto; a registry não anuncia handoff operacional
logístico. Não foram concedidos scopes PRE-DUIMP nem acionadas simulações CI1
como efeito de ativação. Não houve nova migration, mudança tributária, regra
regulatória, seed em demo pública, push ou deploy.

Próximo corte: ligar a coleta/apresentação de preparação e o cockpit proposto
a essa capability server-side, reutilizando os padrões de contexto e retorno
consultados no IMOB. As validações G3/G5, fonte regulatória e operação física
continuam separadas e pendentes.
