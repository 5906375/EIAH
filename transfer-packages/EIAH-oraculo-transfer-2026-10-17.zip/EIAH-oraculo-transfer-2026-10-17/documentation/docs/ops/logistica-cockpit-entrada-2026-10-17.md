# Entrada do cockpit Logística & Comex — 2026-10-17

> Evolução: a preparação já possui persistência local validada; consulte [persistência governada](oraculo-persistencia-preparacao-2026-10-17.md). A descrição abaixo registra o corte anterior de entrada, com seus limites e evidências históricos.

Status: **parcial**, incremento local de frontend. Não publicado.

Reutiliza o `VerticalWorkbenchShell` empregado pelo IMOB, autenticação e sessão existentes. O shell ganhou uma configuração opcional de colunas menores para Logística; o padrão do IMOB foi preservado. Não altera regras cognitivas do launcher, schema, concessões ou execução de operações.

| Rota | Comportamento |
| --- | --- |
| `/app/logistica` | Entrada autenticada do cockpit Oráculo SC; consulta de contexto no servidor antes de renderizar módulos. |
| `GET /api/session/context?domain=logistica` | Fonte de autorização existente: aprovação, instalação ativa, membership e política. Falha bloqueia a tela; pode repetir consulta. |
| `/app/chat?domain=core` | Retorno ao Front Door para consultar liberação/ativação quando acesso está pendente. |
| `/app/chat?domain=logistica` | Retorno ao Front Door com contexto logístico quando autorizado. |
| `/app/logistica/pre-duimp` | Rota já existente; link depende da feature flag e capability própria recebida do servidor. |

## O que o usuário vê

Navegação EIAH → Logística & Comex → validação do acesso → cockpit Oráculo SC com devolução de contêiner vazio, módulo Pré-DUIMP e painel de contexto. Sem acesso, exibe a pendência e retorno ao Front Door. Sem sessão, reutiliza o redirecionamento de login com retorno.

A preparação abre três campos opcionais: porto, depósito e fluxo pretendido. São entradas locais temporárias, sem salvar, enviar ou analisar. Vazios permanecem não informados. O modo somente leitura não oferece preparação. Nenhum botão executa devolução, pagamento ou transmissão.

A consulta do cockpit é cancelada ao desmontar/trocar identidade e o resultado é vinculado ao escopo da sessão em memória. Erros não reaproveitam a projeção armazenada. Esse incremento não altera as regras de acesso próprias do Pré-DUIMP.

## Validação executada

- `pnpm test:logistica-core`: 6 testes API puros e 58 frontend aprovados, incluindo 3 novos do cockpit.
- `pnpm --filter @eiah/web build`: aprovado.
- Typecheck web: falha com os mesmos 62 diagnósticos normalizados do baseline HEAD, sem erros novos nos arquivos deste incremento.
- Chromium com API interceptada: acesso permitido, política negada, somente leitura e indisponibilidade; quatro cenários aprovados, sem overflow horizontal em celular. Capturas desktop/celular e checagem das colunas desktop.

Evidências: `ops/evidence/latest/logistica-cockpit-local-2026-10-17/`.

Pendente: persistência governada da preparação e validação de cenário operacional. Não comprova E2E com identidade real, cobertura legal, operação real, CI remoto ou deploy. A demo inteira permanece referência mapeada; esta entrada não representa sua implementação completa.

Agente envolvido: Codex, sem subagentes.
