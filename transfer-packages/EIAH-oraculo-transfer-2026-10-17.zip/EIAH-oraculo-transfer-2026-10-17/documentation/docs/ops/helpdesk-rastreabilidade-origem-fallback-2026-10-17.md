# Helpdesk — rastreabilidade da origem e fallback, 17/10/2026

Escopo autorizado: registrar a origem e o uso de fallback pelo fluxo existente, sem implementar indicadores. O Profile e o contrato de cobertura não foram modificados nesta etapa.

## Fluxo implementado

```mermaid
flowchart TB
  A["Contrato do Tutor<br/>política e intenção selecionada"] --> B["Engine do Front Door<br/>identifica o ramo executado"]
  C["Dicionário / orientação determinística"] --> B
  B --> D["Launcher transporta<br/>responseTrace sem classificar por conta própria"]
  D --> E["POST /api/helpdesk/session<br/>valida formato e escopo autenticado"]
  E --> F["HelpdeskSession.metadata.responseTrace<br/>registro e timestamp existentes"]
  F --> G["GET /api/helpdesk/sessions<br/>histórico e JSON existentes"]
  G --> H["client_reported<br/>ou unavailable para legado/inválido"]
```

## O que é registrado

Contrato compartilhado `helpdesk.response_trace.v1`, exportado por @eiah/contracts:

- emitter: eiah_frontdoor_engine;
- resolver: tutor_contract_v1, help_dictionary_v1, deterministic_help_v1 ou launcher_decision_v1;
- origin: tutor_contract, help_dictionary, deterministic_help ou unknown;
- fallback: used, not_used ou unknown;
- decisionKind e intentId, quando disponíveis;
- policyVersion 1.0.0 somente no ramo do contrato do Tutor.

O rastreio não duplica o texto da pergunta/resposta. Fica vinculado à interação pelos id, tenantId, workspaceId e createdAt já existentes. O schema restringe identificadores, versões e combinações válidas de resolver/origem/política, rejeitando extensões arbitrárias no objeto de rastreio.

O contrato do Tutor emite seu próprio descritor; o engine o transporta no ramo efetivamente selecionado. Dicionário e orientação determinística têm origem própria, sem ganhar o rótulo de contrato do Tutor. Um bloqueio de política não é automaticamente fallback. Os ramos contextual_fallback/proposal_fallback_reply declaram uso; ramos ainda não instrumentados permanecem com origem/fallback desconhecidos no novo rastreio.

O resumo de run conserva a origem desconhecida quando não há descritor de origem; um booleano explicitamente fornecido pelo guard pode reportar seu estado de fallback. Um argumento omitido não se transforma em not_used no rastreio versionado. Os campos legados de metadata continuam presentes por compatibilidade; consumidores futuros não devem usá-los como substituto de um rastreio ausente.

## Limite de comprovação

A decisão local ocorre no navegador. A API verifica formato e vínculo ao registro autenticado, mas não reexecuta o resolver para provar que o cliente relatou a decisão corretamente. Por isso, a resposta do histórico identifica:

- `assurance=client_reported`: descritor versionado válido, reportado pelo cliente;
- `assurance=unavailable`: rastreio ausente, inválido ou de versão desconhecida; trace=null.

Nenhum desses estados significa server_verified. Um cliente pode mentir sobre um descritor válido; a marca de assurance preserva esse limite. Campos livres como source=tutor_contract_v1, fallbackUsed=false ou assurance=server_verified em metadata não certificam a origem retornada. A API calcula a marca do envelope de saída, sem copiar uma alegação de certificação do cliente.

A comprovação independente pelo servidor continua pendente e é pré-requisito para usar estes registros como origem contratual comprovada na definição da Etapa 10. Este trabalho fornece rastreio reportado; não transforma o relatório em prova canônica, autorização ou evidência de qualidade da resposta.

## Persistência e compatibilidade

- Reutiliza POST /helpdesk/session, GET /helpdesk/sessions e HelpdeskSession.metadata; sem nova tabela, migração, rota, grants ou trilha de telemetria.
- Respostas locais instrumentadas do Tutor/dicionário/orientação determinística passam a satisfazer o critério de persistência mesmo sem run/fallback. Isso evita coletar apenas falhas e omitir esses sucessos. Não torna a coleta um censo de todos os turnos.
- Um descritor totalmente desconhecido não força a persistência de um turno que antes não seria registrado; os demais critérios existentes permanecem.
- A gravação do launcher continua fire-and-forget. Indisponibilidade de API/rede ainda pode impedir o registro; não há garantia de entrega, fila de retry ou confirmação nova nesta etapa.
- Dados antigos não são preenchidos retroativamente. O campo de leitura por interação é adicional; o histórico e o JSON existentes podem transportá-lo sem alterações no Profile.
- Contrato, cálculos, percentuais e endpoint de cobertura permanecem pendentes. Os 21 erros conhecidos do Profile não foram corrigidos neste escopo.

## Validação executada

Evidências em `ops/evidence/latest/helpdesk-response-trace-stage11-2026-10-17/`:

- 132 testes compartilhados, de telemetria, engine e Tutor: aprovados. Incluem origem do Tutor versus dicionário, fallback real, desconhecidos, persistência de sucesso local, schema e baseline de comportamento.
- Cinco testes HTTP com PostgreSQL local dedicado: aprovados. Rotas reais e autenticação existente, registro/recuperação, estados de fallback, legado, rejeição antes de gravar, escopo de escrita e isolamento das leituras padrão por tenant/workspace. Identidades sintéticas e limpeza dos registros do teste.
- Um cenário Chromium com API mockada: entrada real no Front Door seleciona Tutor, launcher envia responseTrace no POST existente e não cria run. Não comprova disponibilidade de backend real ou entrega em produção.
- Build de contratos e web aprovados; typecheck API aprovado. Typecheck web retorna os mesmos 21 diagnósticos normalizados do baseline, sem novos.
- Contrato de cobertura e hash do Profile verificados como inalterados. Nenhum indicador, LLM avaliador, deploy ou commit implementado. Sem subagentes.

Status: implementação de rastreio reportado evidenciada localmente; comprovação independente e indicadores pendentes.
