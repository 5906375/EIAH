# Oráculo SC — validação integrada da base

Data: 17/10/2026. Escopo autorizado: somente validação com dados sintéticos. Nenhuma correção de código, permissão real ou publicação.

## Jornada comprovada no navegador

```mermaid
flowchart LR
 A[Login com senha sintética] --> B[Front Door EIAH]
 B -->|Menu Logística & Comex| C[Cockpit Oráculo SC]
 C --> D[Salvar preparação]
 D --> E[Enviar e vincular EIR sintético]
 E --> F[Conferência humana simulada]
 F --> G[Recarregar e reabrir]
 G --> H[Recuperar documento e conferência]
 H --> I[Alterar contexto invalida correspondência]
 I -->|Voltar ao Front Door| B
```

| Verificação | Resultado | Evidência |
| --- | --- | --- |
| Liberação, ativação, sessão, casos, evidências e negativas pela API | 18 cenários + teste pai aprovados; zero falhas | `ops/evidence/latest/oraculo-integrated-base-validation-2026-10-17/http-integration.log` |
| Core e interface | 6 + 58 testes aprovados; zero falhas | `ops/evidence/latest/oraculo-integrated-base-validation-2026-10-17/core-interface.log` |
| Navegador Chromium com API/DB/storage locais reais | 9 verificações aprovadas | `ops/evidence/latest/oraculo-integrated-base-validation-2026-10-17/browser-results.json` |
| Typecheck web | Zero erros; saída 0 | `ops/evidence/latest/oraculo-integrated-base-validation-2026-10-17/web-typecheck.log` |
| Preservação das fontes | 1.249 arquivos comparados; nenhum alterado | `ops/evidence/latest/oraculo-integrated-base-validation-2026-10-17/source-preservation.json` |

## O que isso resolve

O usuário sintético entra por senha, encontra o cockpit no menu do Front Door, salva uma preparação e recupera seus dados após recarregar. O arquivo baixado corresponde aos bytes enviados. A conferência exige declaração de leitura; mudar o contexto exige conferir novamente. Uma nova leitura divergente preserva a anterior no histórico. Cinco revisões foram recuperadas; a tela móvel de 390 px não apresentou transbordamento horizontal.

Na API, workspace alheio e tokens revogados são bloqueados; somente leitura impede salvar, anexar ou conferir, mas mantém leitura autorizada. Ativar a vertical não concede automaticamente políticas. O acesso ao Oráculo não libera o Pré-DUIMP.

## Limites e execução

Servidor de validação montou routers reais de auth, sessão, preparação e uploads em loopback; não foi executado o bootstrap completo da API de produção. Aprovação, ativação e revogação foram verificadas pela suíte HTTP; não pelas telas administrativas. O navegador usou o workspace sintético ativado pela suíte; não foi uma única jornada de provisionamento integral pelo navegador.

O primeiro ensaio do helper de navegador falhou por selecionar ambiguamente dois botões “Entrar”. Somente o helper de validação foi ajustado para o botão de envio; a falha foi preservada em `ops/evidence/latest/oraculo-integrated-base-validation-2026-10-17/browser-attempt1.log`. A execução final passou, incluindo entrada pelo menu do Front Door.

O banco dedicado local reteve fixtures sintéticas; uploads da suíte HTTP foram removidos por seu teardown. O upload do navegador permanece no diretório local de testes. Servidores iniciados nesta validação foram encerrados. Nenhuma identidade ou política real foi criada ou modificada. Tráfego do navegador para destinos externos foi bloqueado; não houve ampliação de rede.

Anexar ou conferir um EIR não comprova aceite operacional, encerramento de responsabilidade ou de cobranças. Não foram validados integração com depósito, agendamento, extração automática, legislação integral, operação real ou transmissão externa. Pré-DUIMP e Etapa 13 permanecem fora desta etapa.

## Evidência visual

Capturas reais com dados sintéticos: `ops/evidence/latest/oraculo-integrated-base-validation-2026-10-17/review-desktop.png` e `ops/evidence/latest/oraculo-integrated-base-validation-2026-10-17/review-mobile.png`.

Manifesto: `ops/evidence/latest/oraculo-integrated-base-validation-2026-10-17/results.json`. Helpers executados: `ops/evidence/latest/oraculo-integrated-base-validation-2026-10-17/ui-server.ts` e `ops/evidence/latest/oraculo-integrated-base-validation-2026-10-17/browser-check.mjs`.

Status: recorte integrado local aprovado com os limites acima. Não representa liberação operacional da vertical ou do Pré-DUIMP. Próxima etapa candidata, dependente de nova autorização: validar separadamente a jornada do Pré-DUIMP, preservando seus gates.
