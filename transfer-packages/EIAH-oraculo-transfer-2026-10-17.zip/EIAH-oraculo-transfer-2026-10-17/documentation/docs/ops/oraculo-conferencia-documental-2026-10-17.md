# Oráculo SC — conferência documental assistida

Data: 2026-10-17. Status: **conferência assistida e comparação evidenciadas localmente; aceite operacional permanece parcial**.

## Relatório visual

```mermaid
flowchart TB
  A[Front Door EIAH] --> B[Cockpit Oráculo SC]
  B --> C[Preparação salva + referência declarada]
  C --> D[Documento vinculado e íntegro]
  D --> E[Usuário autorizado lê e transcreve os dados]
  E --> F[Servidor compara com a referência salva]
  F --> G[Coerente nos campos conferidos]
  F --> H[Divergente]
  F --> I[Indeterminado]
  G --> J[Conferência registrada em nova revisão]
  H --> J
  I --> J
  J --> K[Alteração de contexto exige nova conferência]
  J --> L[Aceite operacional, responsabilidade e custos pendentes]
```

## Base reutilizada

A abordagem segue a separação existente no IMOB entre dados capturados/observados, comparação e revisão. Foram consultados `imobAttachmentValidation.ts`, o intake documental e os mecanismos de revisão do IMOB. As regras de identificação imobiliária e seus papéis não foram transferidos à Logística.

O S1 do Oráculo já distingue operação, contêiner, local e instante. Este corte registra uma **referência declarada** no caso preparatório, sem convertê-la em operationId, credencial ou autorização S1. Mantém `GovernedCase`, revisões com hash canônico, o upload/core e o cockpit compartilhado. Não cria tabelas, migrações, agentes ou cadastro paralelo.

## Jornada e referência da operação

No formulário existente, o usuário pode salvar o contêiner esperado e a data esperada de devolução. Porto e depósito continuam nos campos de preparação com os estados já existentes. Todos permanecem opcionais para preparar/salvar o caso. A falta de referência do contêiner deixa a correspondência indeterminada quando a conferência é solicitada.

O usuário baixa/lê o documento, seleciona qual documento conferiu e registra contêiner, porto, depósito, data e movimento observados. Também informa página/campo/trecho consultado, observações e declara ter lido o documento. Campos não identificados podem ficar em aberto. Esta entrega registra leitura/transcrição humana; não executa extração automática ou consulta externa.

O cliente não escolhe o resultado e não informa o revisor, hash ou autoridade. O servidor usa os dados salvos no caso, o arquivo vinculado, a identidade autenticada e a revisão esperada.

## Comparação explícita

| Campo | Comportamento |
| --- | --- |
| Contêiner | Compara referência declarada e transcrição, normalizando caixa, espaços e hífens. Sem referência ou observação, resultado indeterminado. Não valida checksum, registro ou titularidade. |
| Porto/depósito | Se informados na preparação, compara o texto normalizado (caixa, acentos e espaços). Não resolve aliases ou identidade oficial do local. `A confirmar` e não aplicabilidade exigindo revisão não viram referência confirmada. |
| Data | Se a data esperada foi salva, compara a data transcrita. Sem referência de data, campo não avaliado. Datas inválidas são recusadas pelo contrato. |
| Movimento | Compara a leitura declarada com devolução de contêiner vazio. Outro movimento diverge; movimento não identificado fica indeterminado. |

Uma divergência produz `divergent`. Sem divergência, referências necessárias ou observações faltantes produzem `indeterminate`. Nos demais casos, o resultado é **coerente nos campos conferidos** (`consistent_in_checked_fields`). Campos opcionais sem referência aparecem como não avaliados: esse resultado não confirma a operação inteira.

## Autorização

Consulta utiliza o contexto logístico existente. Registrar uma conferência exige, cumulativamente:

- instalação e vínculo ativos, com uso permitido pela liberação/revogação do core;
- uso fora do modo somente leitura;
- política exata do workspace `log.oraculo_preparation.write`;
- política exata do workspace `log.oraculo_preparation.content_review`.

Política somente do tenant não basta. As políticas são concedidas no workspace, entre membros ativos, segundo o mecanismo existente; não são uma habilitação profissional ou delegação individual de assinatura. O registro identifica quem declarou a leitura, mas não substitui A1/HITL institucional ou aceite pelo recebedor. Nenhuma política real foi concedida por esta tarefa.

## Rotas

| Método e rota | Função |
| --- | --- |
| `/app/logistica` | Cockpit integrado ao Front Door; preparação, documentos e conferência assistida. |
| `POST/PATCH /api/logistica/oraculo/preparations[/:id]` | Grava a preparação com `operationReference` opcional; PATCH exige revisão esperada. Omissão da referência preserva a anterior; objeto vazio a limpa explicitamente. |
| `POST /api/uploads?agentSlug=oraculo-sc` | Upload autenticado existente. |
| `POST /api/logistica/oraculo/preparations/:id/evidence` | Vínculo existente do documento e seu hash ao caso. |
| `GET /api/logistica/oraculo/preparations/:id/document-reviews` | Histórico de conferências, situação atual e `reviewAllowed` calculados no servidor. |
| `POST /api/logistica/oraculo/preparations/:id/document-reviews` | Registra leitura, observações e resultado calculado, com nova revisão. |
| `GET /api/logistica/oraculo/preparations/:id/revisions` | Histórico completo dos snapshots do caso. |

O POST de conferência recebe `{documentId, expectedRevision, acknowledgedDocumentRead:true, locator, notes, observations}`. Observações aceitam apenas os campos definidos; dados de autoridade ou resultado são recusados.

## Histórico, vínculo e invalidação

Cada conferência contém ator autenticado, horário, método `human_transcription`, documento/hash, revisão de origem, dados observados, comparação e hash do vínculo com a referência do caso. É anexada ao mesmo snapshot e gravada com a revisão na transação já existente. Limite de 100 conferências por caso; não há edição de conferência passada.

A consulta projeta:

- `current`: conferência mais recente daquele documento, contexto compatível e arquivo íntegro;
- `context_changed`: a referência ou o contexto preparado mudou; exige nova conferência;
- `file_unavailable`: arquivo ausente, divergente ou não mais acessível;
- `superseded`: uma conferência posterior foi registrada para o mesmo documento.

Uma indicação antiga de coerência não substitui uma leitura posterior divergente. A consulta não trata toda conferência histórica como válida. Revisões sem os novos campos opcionais mantêm seus hashes. O status `unreviewed` no metadado original do vínculo registra a situação inicial; a projeção atual da conferência vem de `/document-reviews`.

A interface bloqueia a mutação documental enquanto houver edição de contexto não salva e congela a edição durante a gravação. Troca de escopo/identidade segue a remontagem já existente; respostas antigas não atualizam outro caso/sessão.

## Limites preservados

O caso permanece em `DISCOVERY`, sem autorização de execução ou transmissão. Cada conferência registra `operationalAuthorization=false`, `responsibilityClosure=false` e `costClosure=false`. Um EIR apenas anexado, ou uma transcrição coerente, não encerra responsabilidade ou cobranças automaticamente.

A referência e a leitura são declarações humanas, não comprovação de autenticidade do emissor, entrega física, aceite institucional ou conformidade legal integral. Não houve validação de documentos reais do usuário. A entrada permanece pelo Front Door, e Pré-DUIMP mantém seus gates próprios.

## Validação executada

Diretório: `ops/evidence/latest/oraculo-document-review-local-2026-10-17/`.

- 93 testes Oráculo/contratos aprovados, incluindo 7 novos de comparação, dados faltantes, referências pendentes, binding, payload forjado e ausência de fechamento operacional.
- 19 testes HTTP/PostgreSQL aprovados, incluindo o teste pai. Exercitam também os incrementos anteriores de core, upload e persistência; o recorte novo prova grant separado/exato, ator/hash/revisão pelo servidor, histórico, contexto alterado, substituição por conferência divergente, arquivo adulterado, isolamento e revogação somente leitura.
- 6 testes API puros e 58 frontend aprovados.
- Build de contratos/web e typecheck API aprovados. Typecheck web mantém os mesmos 62 diagnósticos normalizados do baseline HEAD.
- 6 cenários Chromium com API, PostgreSQL e armazenamento locais: referência salva, arquivo original baixado, declaração de leitura obrigatória, transcrição/comparação, reabertura, invalidação por mudança de referência, leitura divergente posterior, cinco revisões e viewport mobile. São cenários sintéticos com sessão/grant de teste; não provam login real, revisão humana real ou bootstrap completo do servidor.

Sem alteração de rede, concessão real, commit, push, CI remoto ou deploy.

Próxima etapa operacional: definir e validar o responsável e os critérios de aceite aplicáveis ao cenário concreto antes de encerrar a devolução ou atribuir encerramento de custos.

Agente envolvido: Codex, sem subagentes.
