# Logística & Comex — matriz inicial de cobertura por cenário

Data: 16/10/2026. Status: **proposta** para avaliação de domínio; implementação
operacional **parcial**. Agente: Codex, sem subagentes. Baseline técnico:
`5c4a9b2`; documentos e evidências locais de alinhamento de 16/10.

## Escopo e escolhas ainda necessárias

O owner autorizou prosseguir com validação por cenários concretos, mantendo o
cockpit como visão ampla, e escolheu explicitamente **devolução de contêiner
vazio — recorte já simulado no Oráculo**. Importação PRE-DUIMP permanece como
candidato posterior, sem prioridade presumida sobre a frente Oráculo.

Para importação, obter descrição técnica/NCM proposta, finalidade, origem,
UF de destino, modalidade, regime e data de referência. Para devolução,
obter porto/depósito, direção/etapas do fluxo, intervenientes, responsabilidades
e documentos representativos. Usar referências sintéticas/anonimizadas.
Ausência de dado deve permanecer desconhecida, sem defaults inventados.

Esta matriz reaproveita o caderno Pré-DUIMP fornecido, especialmente a
separação entre aplicabilidade, atendimento e evidência. Não aprova seus
requisitos, não constitui parecer jurídico e não implementa regras novas.

## Registro de cada requisito

| Campo | Conteúdo a registrar |
| --- | --- |
| Identidade | ID versionado, cenário, etapa e responsável |
| Natureza | Obrigação legal, regra operacional/contratual, política corporativa ou recomendação; não misturar |
| Aplicabilidade | Aplicável, não aplicável com justificativa, ou indeterminada |
| Fonte | Órgão/autor, URL, ato/dispositivo ou cláusula, versão, vigência, data de consulta e alcance |
| Entradas | Dados e documentos necessários; unidade, moeda, data e origem quando pertinentes |
| Atendimento | Atendido, pendente, divergente ou não avaliado |
| Evidência | Obtida, indisponível ou desatualizada; referência e integridade |
| Controle EIAH | Contrato/serviço/UI atual e limites do que realmente faz |
| Validação | Teste positivo, negativo, alteração material e indisponibilidade de fonte |
| Resultado interno | BLOCK, REVIEW ou READY, conforme contrato e autoridade aplicáveis |
| Limites | Cobertura, exclusões e pendência para validação humana de domínio |

READY significa prontidão interna do escopo avaliado, nunca aprovação de
órgão público, liberação física ou autorização de transmissão. Falha de
consulta não prova irregularidade. Requisito legal só recebe essa natureza
depois de fonte/dispositivo e aplicabilidade verificados.

## Base transversal já disponível

| Controle | Base existente | Cobertura técnica e limite |
| --- | --- | --- |
| Front Door e continuidade | Sessão, roteador, contratos/engine e padrões IMOB | Padrões disponíveis; domínio logístico do cockpit ainda não integrado à sessão core/imob |
| Identidade e acesso PRE-DUIMP | preDuimpAccessResolver e adapter server-side | Gate shadow por escopo/workspace; não autoriza todo o cockpit |
| Caso e revisões | Contratos PRE-DUIMP e GovernedCase/Revision | Estrutura técnica; conteúdo não comprova correção regulatória |
| Integridade, replay e decisão Oráculo | canonicalization, evaluation, transactionExecutor e SQL CI1 | Evidência sintética de 79 testes S1 e 44 integrados na rodada anterior; não há cadeia operacional real validada |
| Revisão humana | A1 sintético CI1; RFC específico PRE-DUIMP | Não intercambiáveis; adapter PRE-DUIMP permanece hitlApproval=null |
| Não transmissão | readinessOnly/authorizationState/externalTransmissionAllowed nos contratos | Preparação protegida; não é integração Siscomex |

## Cenário piloto A — devolução de contêiner vazio

Selecionado pelo owner nesta conversa. Local/depósito, fluxo e documentos
operacionais ainda não informados. Requisitos abaixo são eixos de verificação,
não obrigações legais presumidas para todo porto ou depósito.

Decisão posterior do owner: porto/depósito e fluxo ficam configuráveis por
operação; sua ausência não impede iniciar preparação. Dados ausentes,
a confirmar e alegação de não aplicabilidade permanecem distintos.
Não aplicabilidade exige justificativa e revisão; não é isenção automática.

| ID | Eixo | Evidência/código existente | Lacuna para cenário real |
| --- | --- | --- | --- |
| A01 | Identidade, competência e escopo | Authorities/scopes/fences no CI1 sintético | Binding com autenticação e escritores operacionais |
| A02 | Veículo, motorista e empresa | Três credenciais sintéticas em evaluateResolvedS1 | Fontes autorizadas e critérios documentais aplicáveis ao local/fluxo |
| A03 | Visita, local e revisão | Vínculo de intenção, estado e expectedRevision | Identidade do terminal/depósito e transições operacionais reais |
| A04 | Prova de devolução | returnProof na saída simulada | Forma de comprovação aceita, emissor, momento e custódia |
| A05 | Revisão e negativa | A1/C3/C5 e mapper de negativas | Competência humana real e política de exceção aplicável |
| A06 | Disponibilidade e revogação | Testes CI1 de expiração, revogação, locks e commit incerto | Participação de todos os escritores operacionais; G3/G5 abertos |
| A07 | Prazos/custos/contestação | Conteúdo visual na demo | Contrato aplicável, atos/dispositivos vigentes e fatos do caso; não generalizar ANTAQ 521/2025 |
| A08 | Efeito físico e recebimento | Fora do recorte técnico validado | Integração, autoridade, comprovante e protocolo operacional específicos |

### Detalhamento técnico do piloto A selecionado

Fluxo de referência existente: intenção de visita → verificação sintética →
entrada simulada → prova de devolução → saída simulada → resultado/auditoria.
Estados existentes: NOT_ENTERED → INSIDE → EXITED. Isso descreve a visita do
veículo no recorte atual; não comprova encerramento contratual da devolução,
baixa no armador, término de detention ou aceite jurídico do equipamento.

| Verificação | Comportamento existente | Limite para não inferir conformidade |
| --- | --- | --- |
| Origem das informações | S1 exige modo SIMULATION e fontes sim-* | Fonte sintética não é cadastro ou autoridade oficial |
| Credenciais | Exatamente três credenciais: motorista, inspeção do veículo e empresa | A quarta entrada EmptyReturn da demo não equivale a quarta credencial no S1; OUT usa prova separada |
| Visita e revisão | Referências de operação/local e expectedRevision devem coincidir | Não é integração com agendamento do depósito |
| Prova OUT | Exige enteredAt e returnProof vinculados à visita, operação, contêiner e local | Ainda falta definir comprovante e emissor aceitos na operação real |
| Tempo da prova | Evento posterior à entrada, não futuro; registro coerente | Comparação temporal não prova que o evento físico ocorreu |
| Integridade | Hash do conteúdo deve coincidir com evidenceRefs | Hash não valida autenticidade do emissor ou verdade do documento |
| Aprovação | sim-return-hitl.v1 vincula decisão ao contexto/hash e admite janela máxima de 300 segundos | Política de cinco minutos é sintética, não prazo legal nem política humana PRE-DUIMP |
| Mudança material | Observação/contexto diferente impede reutilizar aprovação | Materialidade operacional completa ainda precisa de definição por cenário |
| Negativas e replay | Resultado final imutável; revisão/negativa não se torna aprovação por retry | Revisão operacional deve seguir intenção e autoridade próprias |
| Commit incerto | Exige reconciliação; RV27 sem prova de ausência de efeito não finaliza automaticamente | Não fabricar falha ou repetir efeito físico para resolver ausência de resposta |

Base lida: `apps/api/src/services/logistica/oraculo/evaluation.ts`,
`transactionExecutor.ts`, `ci1.integration.test.ts` e manifest pure-v2.
Nenhuma regra foi alterada e nenhum teste adicional era necessário para esta
classificação documental; os resultados sintéticos indexados de 16/10 são
referências da rodada anterior, não uma nova execução regulatória.

Antes da classificação operacional, preencher: depósito/local, armador e
transportador pertinentes, ordem/agendamento aceitos, documento de entrega,
regra de aceite/rejeição e avaria, momento de término de responsabilidade e
custos, fonte contratual/normativa e quem pode confirmar cada fato. Nem toda
condição é obrigação legal; registrar sua natureza e justificativa.

## Cenário candidato B — preparação de importação marítima

Não selecionado ainda. Referências Rxx remetem ao caderno de 21/09 da pasta
do owner, ainda minuta. Cada requisito precisa de fonte e aplicabilidade
verificadas; o conjunto não pode ser tratado como regra universal.

| ID | Eixo do caderno | Controle atual | Pendência |
| --- | --- | --- | --- |
| B01 | Elegibilidade DI/Duimp, participantes e modalidade — R01–03/R07 | Contratos genéricos de caso/contexto | Cenário, habilitação/representação, fluxo e cronograma aplicáveis |
| B02 | Classificação, catálogo e atributos — R04–06 | Estruturas para fatos e proveniência | Descrição e justificativa, tabelas/versionamento e regras oficiais |
| B03 | Tratamento administrativo/LPCO — R08–09 | Espaço contratual, sem cobertura setorial comprovada | Órgãos e condições aplicáveis por item e operação |
| B04 | Sanitário e rastreabilidade — R10–16 | Requisitos documentados, não motor normativo validado | Incidência, exceções, documentos e especialista conforme mercadoria |
| B05 | Origem e defesa comercial — R17–18 | Proveniência/caso | Acordo, prova de origem e medida aplicável, se houver |
| B06 | Valoração, tributos e custos — R19–24 | Sem cálculo tributário operacional comprovado nesta inspeção | UF/regime/data, atos, memória de cálculo e validação especializada |
| B07 | Carga/documentos/alterações — R25 e seguintes | Revisões e canonicalização | Reconciliação real de itens/documentos e materialidade aprovada |
| B08 | Decisão e evidência | Readiness sem transmissão; revisão humana parcial | Aprovação persistida vinculada ao caso e revisão; sem substituir anuência/desembaraço |

## Fontes oficiais: estado de consulta desta rodada

Pontos de partida já existentes no caderno:

- Manual de Importação RFB:
  https://www.gov.br/receitafederal/pt-br/assuntos/aduana-e-comercio-exterior/manuais/despacho-de-importacao
- Tratamento administrativo Siscomex:
  https://www.gov.br/siscomex/pt-br/informacoes/tratamento-administrativos/tratamento-administrativo-na-importacao

As duas tentativas de leitura nesta rodada retornaram 403. Nenhum conteúdo
foi obtido para afirmar atualização normativa em 16/10. O domínio www.gov.br
foi incluído no rascunho de rede, preservando os anteriores; acesso runtime
não confirmado. Manual/índice é ponto de partida, não substitui a leitura do
ato/dispositivo vigente. Fontes estaduais, setoriais e contratuais dependem
do cenário e serão identificadas sem generalizar exigências.

## Critério para classificar a capacidade

- **Atende no escopo comprovado:** cenário delimitado, fontes/aplicabilidade
  verificadas, controle implementado, autoridade válida e evidências/testes
  atuais para as condições declaradas.
- **Auxilia:** organiza fatos/documentos ou oferece hipótese/recomendação;
  revisão ou decisão externa ainda necessária e identificada ao usuário.
- **Bloqueia a ação:** faltam dados, autoridade, integração ou evidência
  obrigatória para aquela ação; registrar motivo sem acusar infração legal
  quando a causa é apenas desconhecimento/indisponibilidade técnica.

Aplicar a classificação por capacidade/ação, não como selo universal da
vertical. Simulação técnica não é atendimento operacional real.

## Próxima etapa

O contrato `oraculo.empty-return-preparation.v1` e o avaliador puro
`assessEmptyReturnPreparation` agora aceitam contexto incompleto. Seguem a
separação coleta/revisão consultada no IMOB, sem copiar regras imobiliárias
nem acrescentar um armazenamento paralelo. Não alteram o contrato S1 que
exige localização resolvida. Não há persistência, rota ou interface conectada
por este corte; preparar/salvar na interface ainda exige integração futura.

Próximo passo de produto: conectar a apresentação e coleta desse contexto ao
cockpit/Front Door, com sessão e autorização logística consistentes. Os dados
locais serão solicitados ao usuário por operação quando necessários à análise
ou ação específica, não como pré-requisito global de desenvolvimento.
Regras/fontes aplicáveis continuam indeterminadas até essa contextualização.
Não implementar regra regulatória por hipótese nem reordenar a frente principal
Oráculo por escolha presumida.
