# Logística & Comex — retomada da base, 17/10/2026

Direção confirmada pelo usuário: encerrar o ciclo de correção do typecheck, retomar Logística & Comex e priorizar Core → Front Door → cockpit → casos e evidências de Oráculo SC/Pré-DUIMP. A Etapa 13 de métricas do Profile fica pendente para depois dessa base.

## Base existente consultada

| Trecho | Estrutura existente | Limite a verificar no fluxo completo |
| --- | --- | --- |
| Acesso | Core de liberação, instalação, membership, sessão e políticas | Não transformar instalação em permissão automática |
| Entrada | Front Door EIAH; cockpit /app/logistica com contexto validado | Revalidar navegação e retorno; preservar reutilização do shell IMOB |
| Oráculo SC | Preparação persistida, casos/revisões, vínculo de documentos e conferência assistida | Validar criar → anexar → conferir → reabrir na mesma jornada e identidade |
| Pré-DUIMP | Módulo do Oráculo, capability e feature flag próprias; interface/contexto shadow | Validar seus gates e o alcance efetivo da persistência; não presumir importação/transmissão operacional |
| Operação | Cenário inicial de devolução de contêiner vazio | Aceite institucional, responsabilidade e custos seguem separados da preparação técnica |

Os relatórios antigos registram cortes históricos. As pendências antigas de persistência e revisão do Oráculo foram parcialmente superadas pelos incrementos posteriores; não serão reimplementadas por leitura isolada desses documentos.

## Baseline executado nesta retomada

- `pnpm test:logistica-core`: 6 testes API puros e 58 frontend aprovados.
- `pnpm test:oraculo-s1`: 93 testes aprovados.
- `pnpm test:pre-duimp-web`: 34 aprovados, uma falha.

A falha está em `apps/web/src/pages/app/logistica/pre-duimp.test.tsx`, no teste de menu global. O array esperado omite `/app/logistica`, que já existe em `SHELL_NAV_ITEMS` de App.tsx. A comparação falha nessa diferença antes de concluir todas as combinações de papéis/flags. Não comprova, por si só, falha de autorização ou execução do Pré-DUIMP.

## Primeiro ajuste proposto, ainda não aplicado

Atualizar apenas o teste de navegação para considerar o cockpit Logística & Comex já implementado. Preservar as verificações de um único Chat canônico, ausência de entrada concorrente IMOB e condicionamento do Pré-DUIMP a seus gates. Reexecutar a suíte completa para revelar qualquer outra divergência, sem enfraquecer assertions ou modificar rotas/permissões.

Esse ajuste será submetido à autorização específica, conforme o fluxo de etapas solicitado pelo usuário. Não foi alterado código da aplicação ou de testes nesta retomada.

Depois desse ajuste, o próximo corte da base será verificar a jornada completa com os mecanismos existentes, confrontando frontend, API e persistência. Uma lacuna funcional encontrada será apresentada separadamente antes da correção. Não se propõe nova estrutura de vertical nem liberação de operação real.

Evidências: `ops/evidence/latest/logistica-base-retomada-2026-10-17/`.

Status: diagnóstico inicial evidenciado; base integral ainda não declarada concluída. Sem concessões, alteração de flags/rede, commit, deploy ou subagentes.
