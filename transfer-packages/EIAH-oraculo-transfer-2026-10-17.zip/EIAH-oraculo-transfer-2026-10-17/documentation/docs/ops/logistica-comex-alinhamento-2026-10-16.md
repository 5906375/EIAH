# Logística & Comex — alinhamento de continuidade em 16/10/2026

Status: **parcial**. Agente: Codex, sem subagentes. Baseline:
`5c4a9b287addf5b7a622ddf63729a75d1e8f508f`. Não altera o roadmap, não ratifica
propostas, não ativa produto e não fecha G3/G5.

## Fontes e prioridade

Prevalecem roadmap v8.1, AGENTS.md, arquitetura agent-driven, Evidence Index e
IA_EIAH.md. `Log&Comex.zip` foi consultado como referência, não como autorização
executável. Seu SHA-256 está no checks.json da evidência abaixo.

Documentos-chave: baseline de 22/08, atualização Logística/Oráculo de 31/08,
retomada C0 de 22/09, caderno Pré-DUIMP de 21/09 com nota de sequência de
22/09, negativas/recuperação de 23/09 e revisão dos PRs de 24/09.

Hierarquia de produto da pasta: **EIAH → Logística & Comex → Oráculo SC
(produto/cockpit) → Pré-DUIMP Governada (módulo inicial)**. O roadmap usa
Logística como vertical pública; esta nota não cria outra vertical nem muda
a ordem de rollout. O código confirma recortes, não o cockpit integral.

A retomada de 22/09 mantém Oráculo SC como frente principal. O caderno
Pré-DUIMP continua minuta pendente de revisão e deixa de ser precedência para
C0 original. A existência de AUTHORITY-05A não lhe concede prioridade ou
autorização automática de implementação.

## Matriz de alinhamento

| Item | Evidência atual | Limite/pendência |
| --- | --- | --- |
| Contratos e S1 Oráculo | SIMULATION, canonicalização e avaliação; 79 testes e typecheck passaram | Não cobre cockpit, radar e inteligência econômico-fiscal integrais |
| CI1, E1/A1, auditoria e replay | Executor canônico, contexto vinculado à conexão/transação; 44 testes PostgreSQL passaram | Papéis e identidade sintéticos; fixture legada mínima |
| Negativas/recuperação | Mapper canônico e recuperação explícita da avaliação histórica imutável | RV27 sem prova de ausência de efeito segue bloqueado; commit incerto não vira FAILED |
| Incorporação à main | Fundação #447/#451, códigos #448/#452 e negativas #449 em 25–26/09 | Merge não prova deploy ou liberação operacional |
| CI Oráculo | Job versionado executa typecheck, S1 e CI1 | Resultado remoto atual não consultado; falhas APE/P1 de 24/09 permanecem observações históricas |
| PRE-DUIMP | Contratos, casos/revisões, lifecycle, interface e autorização shadow presentes | Rota autoriza contexto; não comprova jornada integral persistida |
| Preparar versus executar | readinessOnly=true, authorizationState=NOT_REQUESTED, externalTransmissionAllowed=false | Sem autorização Siscomex/Portal Único |
| Aprovação PRE-DUIMP | Adapter continua hitlApproval=null; integração humana é proposta específica | A1 sintético Oráculo não é autoridade PRE-DUIMP reutilizável automaticamente |
| Fonte financeira/regras | Pendências documentadas no repositório e no caderno | Cenário piloto, fontes vigentes e especialistas ainda necessários |
| Autoridade operacional | SQL CI1 usa authorities/scopes/fences dedicados; busca em apps/api/src não encontrou consumidores operacionais do executor fora de testes | Busca delimitada não certifica todos os escritores globais nem uma instalação existente |

## Execução atual e limites

Evidências em
`ops/evidence/latest/oraculo-ci1-validation/844121ee-fe82-47fc-9ca3-82d67b340a16/`:

- `pnpm test:oraculo-s1`: 79 aprovados, zero falhos/ignorados (`s1.log`).
- `pnpm typecheck:oraculo-ci1`: exit 0 (`typecheck.log`).
- `pnpm test:oraculo-ci1` sem variáveis de conexão herdadas: 44 aprovados,
  zero falhos/ignorados; results.json confirma limpeza e ausência de
  memberships dos papéis restritos. PostgreSQL 16 descartável, sem volumes
  existentes; três migrations CI1 sobre baseline legado mínimo.
- Contratos PRE-DUIMP: comando padrão falhou por dist ausente; com paths TS,
  62 testes passaram e um arquivo falhou ao inicializar por .env ausente.
  Fornecendo DATABASE_URL local, o arquivo continuou bloqueado pelo client
  Prisma gerado ausente. O conjunto inicial de contratos governados passou
  15/15 nas três tentativas. Não somar execuções repetidas nem classificar
  falha de inicialização como regressão funcional comprovada.

checks.json registra comandos, resultados, diagnósticos e identidade do ZIP.
Os logs de falhas intermediárias foram preservados. Não foi aprovada a suíte
completa PRE-DUIMP. Build integral, HTTP PRE-DUIMP, toda a cadeia histórica de
migrations, CI remoto e produção não foram validados nesta rodada.

## Próximo corte proposto: diagnóstico completo de integração Oráculo

### Correção de prioridade recebida do owner nesta conversa

**Atualização de acesso:** uma tentativa posterior em 16/10 respondeu HTTP 200.
O bloqueio de rede descrito abaixo é histórico, não um requisito ainda pendente.
Começou a inspeção dos assets baixados com TLS verificado; ver
[inventário inicial da demo](oraculo-demo-inventario-2026-10-16.md).

Respostas explícitas posteriores do owner: **cockpit integrado ao Front Door**,
preservando contexto e retorno; **mapear a demo inteira e delimitar o corte
depois**. Consultar primeiro o IMOB e reutilizar estruturas compatíveis antes
de criar novas, respeitando o domínio Logística & Comex. Não presumir que toda
interação deve permanecer no chat, nem abrir um produto independente do EIAH.

Primeiras referências locais identificadas para inspeção de reaproveitamento:
`apps/web/src/App.tsx` (front door, domínio e gates),
`apps/web/src/pages/app/imob/chat.tsx`,
`apps/web/src/pages/app/imob/dashboard.tsx`,
`apps/web/src/state/sessionStore.ts`,
`apps/api/src/services/imob/imobAgentContract.ts` e
`apps/api/src/services/imob/crm/imobCrmTurnContinuity.ts`.
São candidatos a estudo, não decisão de copiar ou generalizar regras IMOB.
A nova tentativa de acesso à demo após essas respostas também retornou 403;
o inventário integral de telas permanece bloqueado, sem corte definido.

Em 16/10, após este relatório, o usuário reafirmou que o frontend Oráculo SC
deve seguir a demo https://oraculosc.vercel.app/. Esta é a referência indicada
para experiência visual e navegação do produto/cockpit. A descrição anterior
do próximo corte ficou incompleta por omitir essa direção de frontend.

O próximo entregável deve começar pelo inventário de telas, componentes e
jornadas da demo e pelo mapa de reaproveitamento no React/Vite existente.
Esse inventário deve distinguir dados demonstrativos, capacidades reais e
controles ainda indisponíveis; não deve redesenhar o cockpit por inferência
nem reduzir o produto à tela shadow PRE-DUIMP. Regras de domínio continuam
em contratos/engine, com launcher apenas renderizando decisões resolvidas.

Nesta rodada, a tentativa de acessar a URL foi recusada pelo proxy da nuvem
(CONNECT 403); não houve inspeção visual da demo. A liberação do hostname foi
salva no rascunho de rede, preservando binaries.prisma.sh. É necessário salvar
a configuração de rede do ambiente e repetir o acesso antes de declarar
fidelidade à demo. O diagnóstico de autoridade abaixo permanece necessário
para integração funcional, sem substituir ou apagar a prioridade visual.

Antes de conectar rota/worker, completar a matriz de escritores/consumidores
de autoridade: identidade autenticada, revogação de token, competência humana,
instalação, policy, tenant/workspace e chave global. Para cada alteração,
identificar transação, barreira de concorrência, observador e comportamento
de indisponibilidade. Os fences do harness não demonstram participação dos
escritores operacionais existentes.

Entregável: proposta concreta do binding de autenticação com CI1,
provisionamento dos quatro papéis, política de revogação e testes exigidos.
Condição de saída: nenhuma autoridade vinda do payload; nenhuma alteração
relevante fora da barreira; falha fechada se a revalidação não puder ocorrer.
Escritor sem cobertura impede habilitação operacional por aproximação.

Em paralelo, concluir setup Prisma/backend para validar PRE-DUIMP. Revisar o
caderno e escolher cenário piloto antes de ampliar cobertura funcional.
Confrontar AUTHORITY-05A com o aprendizado CI1 preservando os domínios.

## Alterações desta tarefa

Apenas documentação e evidências sintéticas. Sem mudança de aplicação,
contratos, schema, migrations, flags ou credenciais. Sem push, merge, deploy,
integração externa ou promoção operacional. Relatos antigos não foram
reescritos como resultados atuais.
