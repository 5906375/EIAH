# Oráculo SC — inventário inicial da demo em 16/10/2026

Continuidade: [mapa ampliado, comparação IMOB e corte proposto](oraculo-demo-imob-corte-frontend-2026-10-16.md).
Inclui ramificações internas, 14 visitas desktop/mobile e 22 passos de
interação local, sem executar escrita remota. Estados preenchidos dependentes
da API continuam sem validação dinâmica.

Status: parcial. Agente: Codex, sem subagentes. Referência do owner:
https://oraculosc.vercel.app/. Cockpit integrado ao Front Door; mapear toda a
demo antes de delimitar o corte. Reutilizar IMOB quando compatível.

## Acesso e método

O acesso HTTP voltou a responder 200 após o bloqueio de rede anteriormente
observado. Isso não comprova publicação do ambiente. HTML e assets JS/CSS
foram baixados por curl com TLS verificado. O Chromium local rejeitou o
certificado do acesso remoto; nenhuma verificação TLS foi desativada.

Inspeção em navegador de cópia local dos assets baixados, com chamadas fora
do servidor loopback bloqueadas. Sete rotas foram abertas pelos links da
aplicação. A captura visual do dashboard foi examinada. JSONs com texto e
controles, HTML, assets e screenshots ficam em
`/workspace/logcomex-review-2026-10-16/`. Essa cópia não prova conectividade
do backend da demo nem equivalência com dados do ambiente original.

## Navegação observada

| Rota da demo | Superfície e controles observados | Limite |
| --- | --- | --- |
| / | Dashboard: entradas, saídas, VCs, anomalias, eventos, gates e agentes | Estado inicial zero, Demo/API Off |
| /gate | Placa, agendamento, quatro credenciais; Verificar e Liberar Entrada | Botões não executados; liberação física não autorizada |
| /vcs | Placa, JWT e cartões de motorista, veículo, empresa e devolução vazia | Texto EdDSA/CRL não comprova validação criptográfica operacional |
| /audit | Indicadores, tabela e filtros GateIn/GateOut/negados/anomalias | Sem registros no estado capturado |
| /chain | Cadeia logística; filtros exportador/importador; estados de comprovação | Sem itens no estado capturado |
| /payments | Pagamentos por status e tipo: frete, imposto, demurrage, serviço | Promessas de PIX/DARF/WhatsApp são texto da demo, não capacidade comprovada |
| /metrics | Superfície Métricas | Erro ao carregar na cópia com rede externa bloqueada; causa remota não diagnosticada |

Layout observado: menu lateral azul escuro, indicação da área ativa, operador
no rodapé, cabeçalho contextual, cartões claros e painéis/tabelas. A identidade
do operador exibida é conteúdo da demo, não fonte de identidade EIAH.

## Pendências antes de definir o corte

Inspecionar modo demonstrativo, estados preenchidos e vazios, filtros,
detalhes/modais, validação dos formulários, responsividade e navegação de
retorno. Capturas das rotas não equivalem a testar todos os fluxos.

Cruzar cada superfície com dashboard/chat, sessionStore, contratos de agente,
gates e continuidade IMOB. Identificar o que pode ser reutilizado e justificar
lacunas antes de criar estrutura. Preservar regras no contrato/engine e
apresentação na interface. Separar capacidades simuladas de operação real;
nenhum item deste inventário autoriza integração externa ou transmissão.

Pré-DUIMP não apareceu no menu destas sete rotas. Sua inclusão como módulo
decorre do baseline de produto do owner, não de uma tela observada na demo.
