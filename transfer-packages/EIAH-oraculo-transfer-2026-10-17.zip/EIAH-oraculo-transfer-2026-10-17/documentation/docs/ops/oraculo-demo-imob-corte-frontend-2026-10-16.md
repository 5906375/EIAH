# Oráculo SC — demo, reaproveitamento IMOB e corte de frontend

Data: 16/10/2026. Status: **parcial**; corte de implementação **proposto**.
Agente: Codex, sem subagentes. Baseline de código: `5c4a9b2`.

## Direção confirmada pelo owner

- Entrada e continuidade pelo Front Door EIAH, com cockpit integrado e retorno
  preservando contexto; não é obrigatório manter toda interação dentro do chat.
- Demo https://oraculosc.vercel.app/ como referência de frontend; mapear o
  conjunto antes de delimitar o corte.
- Consultar IMOB e reutilizar estruturas compatíveis antes de criar novas.
- Logística & Comex é a vertical; Oráculo SC é o cockpit/produto; Pré-DUIMP
  Governada é módulo especializado, não outro produto independente.

## Escopo efetivamente inspecionado

Sete rotas abertas por links no navegador em desktop (1440×1000) e mobile
(390×844), incluindo abertura do menu mobile. Sem overflow horizontal do
documento nesses estados. Foram registrados 22 passos de interação, abrangendo
filtros, botão de verificação vazio, erro de rede de verificação com token
sintético, estado inicial da liberação e falha do carregamento de demo.

Método: assets obtidos com curl/TLS verificado e renderizados localmente;
requisições externas bloqueadas no navegador. Os POSTs de verificação e seed
foram interceptados/abortados, não executados no ambiente público. O Chromium
remoto rejeitou o certificado; nenhuma verificação foi desabilitada.

A API indicada nos assets é https://eiah-log.vercel.app/. A leitura inicial
de /v1/chain recebeu CONNECT 403 do proxy. O hostname foi adicionado ao
rascunho preservando os anteriores; acesso runtime ainda não confirmado.
Não foram executados seed remoto, pagamento, gate, booking, notificação ou
compartilhamento. Dados preenchidos e modais dependentes desses dados foram
mapeados pelo código publicado; não equivalem a fluxos completos testados.

Evidências: `ops/evidence/latest/oraculo-demo-discovery-2026-10-16/`, com
results.json, DOM/textos, interações, inventário de strings por componente,
screenshots e MANIFEST.sha256. Não são evidências de operação produtiva.

## Mapa da demo inteira: rotas e ramificações encontradas

| Área | Conteúdo e estados | Origem da observação |
| --- | --- | --- |
| Dashboard | KPIs de entrada/saída/VC/anomalias, eventos, status de gates e agentes; loading, vazio e falha de seed | Navegador e código |
| Gate Control | Placa, agendamento, quatro credenciais, verificação, última decisão e liberação inicialmente desabilitada | Navegador e código; liberação não executada |
| Verificação VCs | JWT/placa, motorista, veículo, empresa e prova de devolução; erro de rede e botão vazio desabilitado | Navegador; EdDSA/CRL apenas alegação textual, sem prova funcional |
| Auditoria | KPIs, tabela desktop/cartões mobile, filtros Todas/GateIn/GateOut/Negados/Anomalias | Filtros exercitados sem registros |
| Cadeia LOG_E2E | Seleção de casos, importador/exportador, etapas, responsabilidades, estados OK/parcial/contestável/sem prova/bloqueado | Lista/filtros em navegador; detalhes pelo código |
| Evidências na cadeia | Documento, foto, WhatsApp, URL e descrição manual; classificação de força | Modal pelo código; registro local de nome não prova upload, custódia ou recebimento WhatsApp |
| Compartilhamento | Ator, contato e expiração 2h/24h/7d; link, copiar e visão filtrada por shareToken | Código; não foi gerado link real |
| Tracking/booking/VGM | Hapag-Lloyd, tracking, real versus simulado, booking e submissão VGM | Código; integração e efeitos externos não validados |
| Aduaneiro | Validação NCM/DU-E, achados por item, canal DI, simulação/reset e alertas | Código; regras jurídicas e fontes não validadas |
| Demurrage/detention | Free time, exposição/custos, contestação e alerta WhatsApp | Código; afirmações ANTAQ/cron não são capacidade comprovada ou regra aprovada |
| Pagamentos | Resumo, filtros status/tipo, parcelas tributárias, PIX e contestação | Filtros exercitados sem registros; ações somente lidas no código |
| Métricas | KPIs, NCM/histórico, canal DI, distribuição de etapas, tempos, demurrage e economia | Erro em navegador sem API; estado preenchido pelo código |

Pré-DUIMP não está no menu publicado de sete rotas. Não inventar uma tela
observada: sua presença futura vem do baseline de produto e do módulo já
existente no EIAH. A demo portuária também não representa toda a visão de
inteligência econômico-fiscal documentada na pasta do owner.

## Comparação concreta com IMOB e core

| Necessidade Oráculo | Estrutura existente consultada | Decisão de reaproveitamento |
| --- | --- | --- |
| Acesso, shell e continuidade | apps/web/src/App.tsx; state/sessionStore.ts; components/agents/FrontDoorSessionHeader.tsx | Reutilizar roteador, autenticação e sessão; estender contrato canônico antes de adicionar domínio |
| Caso ↔ cockpit ↔ conversa | features/imob/imobCommandCenterHelper.ts, buildImobChatRoute; pages/app/imob/dashboard.tsx e chat.tsx | Reutilizar padrão de referências e retorno, sem gerar IDs IMOB/Run falsos para Oráculo |
| Resposta e descoberta governadas | services/imob/imobAgentContract.ts; imobCapabilityRegistry.ts; imobCapabilityGate.ts | Reutilizar arquitetura contrato → engine → apresentação; definir capacidades logísticas próprias |
| Painéis e filtros | features/imob/ImobCommandCenter.tsx; ImobDashboardHero.tsx | Referência de composição, estados e integração; não copiar componente inteiro com semântica imobiliária |
| Loading/refresh sem apagar snapshot | features/imob/kpiRefreshState.ts | Candidato a reutilização direta ou extração mínima quando houver segundo consumidor concreto |
| Acesso indisponível e reason codes | components/imob/ImobAccessGateCard.tsx; features/imob/accessGateCatalog.ts | Reusar padrão visual; não usar motivos/permissões IMOB para conceder acesso logístico |
| Evidências/governança | components/runs/GovernancePanel.tsx; RunTimeline.tsx; lib/api.ts | Reusar componentes somente se o contrato real corresponder; não fabricar runId nem confundir C5 com receipt de Run |
| Casos/avaliações logísticas | preDuimpGovernedCaseRepository.ts; logistica/oraculo/transactionExecutor.ts | Reusar contratos próprios já existentes; não transplantar ImobCase ou o lifecycle imobiliário |
| Módulo PRE-DUIMP | pages/app/logistica/pre-duimp.tsx; features/logistica/preDuimp.ts; preDuimpAccessResolver.ts | Preservar entrada shadow e gates; permissão PRE-DUIMP não autoriza automaticamente todo o cockpit |

Lacuna confirmada: `activeDomain`, `apiGetSessionContext` e allowlist do
servidor aceitam somente core/imob. `conversationDomainLabel` também só
apresenta IMOB/EIAH. Não basta criar uma rota ou alterar apenas o frontend.
A sessão/autorização logística precisa de contrato server-side consistente.
LOGISTICA já é o product usado pelo resolver PRE-DUIMP; não criar outro código
de produto por conveniência. Nenhuma nova permissão é concedida nesta nota.

## Corte recomendado: cockpit demonstrativo integrado, sem execução externa

Objetivo: reproduzir a organização visual da demo dentro do EIAH, com entrada
e retorno pelo Front Door e contexto real de sessão. Não transplantar a SPA
como outro login/app nem transformar a tela shadow na totalidade do cockpit.

Sequência de implementação proposta:

1. Estender de forma consistente o contrato de contexto logístico do Front
   Door entre servidor, cliente e apresentação. Identificar no catálogo atual
   a decisão de acesso aplicável; capability PRE-DUIMP e instalação isolada
   não substituem a autorização específica do cockpit. Falhar fechado.
2. Compor o shell do cockpit no roteador existente, com identidade da sessão,
   retorno explícito ao EIAH e restauração das referências de operação/caso
   suportadas. Preservar tenant/workspace sem usar identidade fixa da demo.
3. Cobrir as sete áreas visuais com estados de carregamento, vazio, falha e
   indisponibilidade. Fixtures sintéticas claramente identificadas em modo
   demonstrativo, separadas de dados operacionais e sem fallback silencioso.
   Preservar a paleta e a organização da demo conforme os tokens existentes.
4. Apresentar o módulo PRE-DUIMP existente dentro da jornada, com seu gate
   próprio. Não inventar a funcionalidade regulatória ainda em minuta.
5. Manter ações externas indisponíveis com motivo concreto: liberar gate,
   pagar/contestar, compartilhar externamente, enviar WhatsApp, booking/VGM e
   comandos Siscomex. Não conectar a API pública da demo como backend EIAH.
6. Detalhes de cadeia/evidência podem usar apenas fixtures neste corte; não
   apresentar armazenamento local de rótulos como evidência auditável real.

Critérios de aceite: caminho Front Door → cockpit → Front Door preserva
contexto; acesso direto também verifica autorização; troca de workspace e
revogação não mantêm acesso anterior; sem chamadas mutantes externas; nenhum
KPI fictício parece dado real; sete áreas cobertas em desktop/mobile; modo
indisponível distinguível de vazio; comportamento nasce em contrato/engine.

## Dependências e limites para avançar

A implementação acima é proposta baseada nas fontes consultadas, não código
aplicado. O inventário de todas as rotas/ramificações está registrado, mas a
inspeção dinâmica preenchida permanece parcial enquanto faltar leitura da
API da demo. Essa inspeção não requer clicar em seed, pagar ou liberar gate.

O diagnóstico de autoridade G3/G5 continua em paralelo para futura conexão
funcional. Backend Prisma ainda incompleto nesta nuvem. Fixtures de frontend
não fecham esses gates nem aprovam o caderno regulatório PRE-DUIMP.
