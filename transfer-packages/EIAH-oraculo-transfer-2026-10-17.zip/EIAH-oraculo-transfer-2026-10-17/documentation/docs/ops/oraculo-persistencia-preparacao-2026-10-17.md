# Oráculo SC — persistência governada da preparação

> Evolução: documentos e evidências já podem ser vinculados ao caso; consulte [vínculo e integridade técnica](oraculo-documentos-evidencias-2026-10-17.md). O registro abaixo preserva o corte de persistência e suas evidências.

Data: 2026-10-17. Status: **evidenciado localmente; operação e publicação permanecem parciais**.

## Reutilização

Mantém o cockpit integrado ao Front Door em `/app/logistica`. Reutiliza `GovernedCase` e `GovernedCaseRevision`, a canonicalização JSON já usada pelo Pré-DUIMP e seu padrão de transação/revisão otimista. A implementação de domínio do Pré-DUIMP permanece específica; não é chamada para criar um caso Oráculo. O novo tipo é `ORACULO_EMPTY_RETURN_PREPARATION_V1`, com snapshot versionado `oraculo.empty-return-preparation.v1`. Não cria tabelas, migrations, agentes, cadastros ou serviços externos.

## Acesso

Toda rota passa pelo `enforceTenant` existente. Tenant, workspace e ator vêm da sessão autenticada, nunca do payload ou dos headers de escopo. O resolver logístico existente exige instalação ativa, aprovação, vínculo ativo e política exata `log.context.read`.

Consulta exige esse contexto. Criação/edição também exige `usage=full` e política **exata do workspace** `log.oraculo_preparation.write`. Uma política apenas do tenant não basta. A permissão é do workspace entre seus membros ativos, conforme o store existente; não atribui um papel de revisor nem autoridade operacional individual. Instalação/ativação não concede a política. Revogação somente leitura permite consulta e histórico, mas bloqueia gravação; bloqueio total impede ambos. Nenhuma permissão real foi concedida nesta tarefa.

Os novos códigos HTTP de recusa/conflito foram registrados como `proposed` no canon existente, sem approver ou ratificação operacional. O checker do canon passou; não houve promoção a `active`.

## Rotas

Prefixo: `/api/logistica/oraculo/preparations`.

| Método e sufixo | Resultado |
| --- | --- |
| `GET /` | Até 100 preparações mais recentes do workspace e `writeAllowed` calculado no servidor. |
| `POST /` | Cria uma preparação e sua primeira revisão na mesma transação. Corpo restrito a `{context}`. |
| `GET /:id` | Reabre uma preparação do tipo e escopo autenticados. |
| `PATCH /:id` | Atualiza com `{context, expectedRevision}`; revisão divergente retorna 409. |
| `GET /:id/revisions` | Histórico de snapshots do caso acessível no escopo. |

IDs de outro workspace ou tenant não são retornados. O caso e todas as revisões permanecem em `DISCOVERY`, com `executionAllowed=false`, `authorizationState=NOT_REQUESTED` e `externalTransmissionAllowed=false`. Texto do usuário não é uma evidência validada.

## Gravação e integridade

A projeção e a nova revisão são gravadas numa transação. O update compara a revisão esperada; duas edições simultâneas da mesma revisão produzem um sucesso e um conflito, sem sobrescrever o vencedor. Falha no append do histórico desfaz a projeção.

Cada snapshot tem hash SHA-256 do JSON canônico e validação de contrato, escopo, ID, revisão, versão e lifecycle nas leituras. Divergência bloqueia leitura/edição com 409. O histórico é append-only por estas rotas; não há endpoint de exclusão ou alteração de revisão passada. Isso não equivale a assinatura criptográfica ou proteção contra um administrador com acesso irrestrito ao banco.

Não implementa idempotência de criação. Em falha de rede com resultado incerto, a UI bloqueia nova gravação até atualizar a lista; o usuário deve verificar se o registro foi criado antes de iniciar outro.

## Interface

O usuário escolhe uma preparação salva ou inicia uma nova, informa opcionalmente porto, depósito e fluxo e salva explicitamente. Cada campo oferece `Não informado`, `A confirmar`, `Informado` ou `Não se aplica — requer revisão`. Não aplicabilidade exige justificativa; informar exige texto; limite de 500 caracteres. Um campo vazio em `Não informado` não impede salvar.

Recarregar a página e reabrir o registro restaura os dados salvos. A tela mostra revisão e histórico dos valores anteriores. Em conflito, preserva a edição local e solicita atualizar/reabrir. Troca de identidade/workspace remonta o conteúdo; respostas de componentes antigos não alteram a nova sessão. Um erro de consulta não libera gravação.

## Evidência executada

Diretório: `ops/evidence/latest/oraculo-preparation-persistence-local-2026-10-17/`.

- 12 testes integrados (incluindo o teste pai) aprovados em PostgreSQL local dedicado: core, autorização separada, payload forjado, isolamento, persistência, histórico, concorrência, rollback, integridade e revogação.
- 6 testes API puros e 58 frontend aprovados no runner `test:logistica-core`.
- 86 testes Oráculo/contratos e regressões relacionadas aprovados.
- Build de contratos, build web e typechecks API/core aprovados.
- Typecheck web segue falho com os mesmos 62 diagnósticos normalizados do baseline HEAD.
- Chromium com sessão sintética, **rotas HTTP reais e PostgreSQL**, sem interceptar respostas da API: validação de campos, criar, recarregar/reabrir, editar, conflito entre abas, histórico e viewport mobile. Harness monta routers existentes; não testa o bootstrap integral do servidor nem cadastro/login real.

Fixtures e políticas de teste ficam no banco isolado `eiah_logistica_core_20261016`. O harness recusa outros bancos e usa apenas tokens sintéticos previamente criados pelos testes; nenhum token é incluído nas evidências. Não há commit, push, CI remoto ou deploy nesta tarefa.

## Limites operacionais

Persistir preparação não valida legislação, documentos, porto/depósito, responsabilidade, custos ou aceite da devolução. Não produz S1, não fecha G3/G5, não autoriza gate, pagamento ou transmissão aduaneira. Pré-DUIMP mantém seu gate próprio.

Próxima lacuna funcional: vincular evidências e avaliações de cenário ao caso usando os mecanismos existentes, antes de qualquer conclusão operacional.

Agente envolvido: Codex, sem subagentes.
