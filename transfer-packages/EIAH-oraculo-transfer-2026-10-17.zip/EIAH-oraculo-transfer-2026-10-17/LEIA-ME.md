# Pacote de transferência — Oráculo SC / Logística

Preparado em 17/10/2026. Somente preparação autorizada. Sem commit, push, deploy, migração ou aplicação na cópia de destino.

## Leia primeiro

Na cópia de destino, ler primeiro o CLAUDE.md local e seguir as instruções aplicáveis. As cópias em reference-only são contexto da origem, não substituem as regras do destino.

**Não aplicar automaticamente.** Este pacote contém a árvore alterada atual, não um patch mínimo isolado da vertical. Inclui contexto compartilhado e correções de etapas anteriores (Core, IMOB, typecheck, Profile e rastreabilidade). Isso preserva a referência da implementação validada; não autoriza introduzir todas essas alterações no destino.

## Conteúdo

- `MANIFEST.json`: HEAD/branch de origem, grupos, arquivos novos/alterados, hashes atuais e da base.
- `SHA256SUMS`: hashes de todos os demais arquivos internos.
- `changes.patch`: diff dos arquivos de código/configuração selecionados contra HEAD, incluindo arquivos novos.
- `working-tree/`: conteúdo final dos arquivos alterados ou novos de apps/packages, package.json. Workflow CI excluído; revisar separadamente se a integração futura exigir.
- `base-head/`: conteúdo HEAD dos arquivos rastreados alterados, para comparação de três versões; arquivos novos não têm base.
- `documentation/`: relatórios de Logística/Oráculo e contexto das etapas compartilhadas selecionadas.
- `reference-only/`: normas, índice de evidências e configurações de referência; não copiar sobre o destino.
- `evidence/`: logs, resultados, capturas e helpers da última validação integrada local.
- `VALIDATION.json`: verificações desta preparação. Não equivale a teste de integração no destino.

## Próximo agente: somente consulta e comparação nesta etapa

1. Extrair em pasta separada, fora do checkout de destino. A extração não deve sobrescrever código.
2. Verificar o SHA-256 externo do ZIP e os hashes internos (por exemplo, `sha256sum -c SHA256SUMS`, na pasta extraída).
3. Ler `documentation/docs/ops/logistica-comex-passagem-agente-2026-10-17.md`.
4. Comparar HEAD/árvore local do destino com MANIFEST e as versões `base-head/` e `working-tree/`. Preservar alterações locais do destino.
5. Classificar arquivos novos, iguais, divergentes e conflitos. Não afirmar que 88bb3a2 e 5c4a9b2 são compatíveis sem verificar ancestralidade e conteúdo na cópia real.
6. Distinguir mudanças necessárias à vertical de correções anteriores compartilhadas; apresentar uma proposta concreta de aplicação por etapa e aguardar autorização. Não executar `git apply`, copiar arquivos sobre o checkout, iniciar serviços, fazer login, conceder permissões, migrar, publicar ou fazer deploy nesta autorização.
7. Só após autorização de implementação e validação local, tratar compatibilidade/versão do Render em etapa separada. Este pacote não comprova que as rotas estejam implantadas.

## Evidência e limites

A execução histórica local aprovou 18 cenários HTTP mais teste pai, 64 testes Core/interface, nove verificações no navegador e typecheck web sem erros. Servidor usou routers reais selecionados, não o bootstrap completo de produção. Consulte evidence e o relatório para os limites. Não foram repetidos testes funcionais para empacotar.

O helper usa paths privados da máquina de origem. Credenciais, fixtures privadas, uploads e banco não foram incluídos. Não o execute esperando reprodução automática. Preparar um ambiente isolado requer planejamento e autorização próprios.

O patch passou em `git apply --check` contra bases exportadas do HEAD de origem, sem aplicação. Isso comprova consistência com essa base exportada, não compatibilidade com o destino.

A busca por padrões de segredos nos payloads selecionados não encontrou ocorrências dos padrões examinados; não é garantia geral. Nenhum arquivo privado de credenciais foi selecionado. Placeholders fixos de banco local já existentes nos scripts de teste do package.json foram preservados como código; não são credenciais do ambiente e foram explicitamente reconhecidos pelo scanner.

Agente: Codex. Sem subagentes. Status: pacote preparado para revisão; integração no destino e Render não executadas.
