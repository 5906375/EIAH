import test from "node:test";
import assert from "node:assert/strict";
import { HelpdeskResponseTraceV1Schema, readHelpdeskResponseTrace } from "../src/helpdeskResponseTrace";

const trace = {
  version: "helpdesk.response_trace.v1", emitter: "eiah_frontdoor_engine",
  resolver: "tutor_contract_v1", origin: "tutor_contract", fallback: "not_used",
  decisionKind: "help_reply", intentId: "billing_overview", policyVersion: "1.0.0",
};

test("versioned trace round-trips only as client reported, not server verified", () => {
  const view = readHelpdeskResponseTrace({ responseTrace: trace });
  assert.equal(view.assurance, "client_reported");
  assert.deepEqual(view.trace, trace);
});

test("missing and invalid legacy metadata cannot be upgraded from source or fallback booleans", () => {
  for (const metadata of [undefined, null, [], {}, {source:"tutor_contract_v1",fallbackUsed:false},
    {responseTrace:null}, {responseTrace:{...trace,version:"future"}}]) {
    assert.deepEqual(readHelpdeskResponseTrace(metadata), {assurance:"unavailable",trace:null});
  }
});

test("trace rejects arbitrary claims, incompatible origin/resolver, policy and text extensions", () => {
  for (const invalid of [{...trace,serverVerified:true},{...trace,origin:"help_dictionary"},
    {...trace,policyVersion:null},{...trace,intentId:"private text @example.com"},
    {...trace,fallback:false},{...trace,message:"content"}]) {
    assert.equal(HelpdeskResponseTraceV1Schema.safeParse(invalid).success,false);
  }
});
