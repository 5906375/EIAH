import { z } from "zod";

/** Report of the executed client-side branch, never server verification of that branch. */
export const HelpdeskResponseTraceV1Schema = z.object({
  version: z.literal("helpdesk.response_trace.v1"),
  emitter: z.literal("eiah_frontdoor_engine"),
  resolver: z.enum(["tutor_contract_v1", "help_dictionary_v1", "deterministic_help_v1", "launcher_decision_v1"]),
  origin: z.enum(["tutor_contract", "help_dictionary", "deterministic_help", "unknown"]),
  fallback: z.enum(["used", "not_used", "unknown"]),
  decisionKind: z.string().regex(/^[a-zA-Z0-9_.:-]+$/).max(128),
  intentId: z.string().regex(/^[a-zA-Z0-9_.:-]+$/).max(128).nullable(),
  policyVersion: z.literal("1.0.0").nullable(),
}).strict().superRefine((trace, ctx) => {
  const expected = {
    tutor_contract_v1: "tutor_contract", help_dictionary_v1: "help_dictionary",
    deterministic_help_v1: "deterministic_help", launcher_decision_v1: "unknown",
  } as const;
  if (trace.origin !== expected[trace.resolver] ||
      (trace.origin === "tutor_contract" ? trace.policyVersion === null : trace.policyVersion !== null)) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Trace resolver, origin and policy must agree" });
  }
});

export type HelpdeskResponseTraceV1 = z.infer<typeof HelpdeskResponseTraceV1Schema>;
export type HelpdeskResponseTraceViewV1 = {
  assurance: "client_reported" | "unavailable";
  trace: HelpdeskResponseTraceV1 | null;
};

/** Old booleans/source strings do not establish a versioned decision trace. */
export function readHelpdeskResponseTrace(metadata: unknown): HelpdeskResponseTraceViewV1 {
  const candidate = metadata && typeof metadata === "object" && !Array.isArray(metadata)
    ? (metadata as Record<string, unknown>).responseTrace : undefined;
  const parsed = HelpdeskResponseTraceV1Schema.safeParse(candidate);
  return parsed.success ? { assurance: "client_reported", trace: parsed.data }
    : { assurance: "unavailable", trace: null };
}
