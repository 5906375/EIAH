import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { before, after, test } from "node:test";
import express from "express";
import supertest from "supertest";
import { closePrismaResources, prismaGlobal } from "@repo/db";
import type { HelpdeskResponseTraceV1 } from "@eiah/contracts";
import { helpRouter } from "../routes/help";

const url = new URL(process.env.DATABASE_URL ?? "postgresql://unused/unused");
if (!["127.0.0.1", "localhost"].includes(url.hostname) || !url.pathname.startsWith("/eiah_logistica_core_")) {
  throw new Error("Dedicated local eiah_logistica_core_ test database required");
}
const suffix=randomUUID();
const tenantId=`trace-tenant-${suffix}`, workspaceId=`trace-work-${suffix}`, otherWorkspace=`trace-other-work-${suffix}`;
const otherTenant=`trace-other-tenant-${suffix}`, foreignWorkspace=`trace-foreign-work-${suffix}`;
const token=`synthetic-trace-${suffix}`, otherToken=`synthetic-other-trace-${suffix}`, foreignToken=`synthetic-foreign-trace-${suffix}`;
const app=express();app.use(express.json());app.use("/api",helpRouter);
const request=supertest(app);
const trace:HelpdeskResponseTraceV1={version:"helpdesk.response_trace.v1",emitter:"eiah_frontdoor_engine",
  resolver:"tutor_contract_v1",origin:"tutor_contract",fallback:"not_used",decisionKind:"help_reply",
  intentId:"billing_overview",policyVersion:"1.0.0"};
const body=(responseTrace:unknown)=>({tenantId,workspaceId,intent:"help",confidence:1,message:"Synthetic question",
  response:"Synthetic response",metadata:{responseTrace}});
const auth=(value=token)=>`Bearer ${value}`;

before(async()=>{
  await prismaGlobal.tenant.createMany({data:[{id:tenantId,name:"Synthetic trace"},{id:otherTenant,name:"Synthetic other trace"}]});
  await prismaGlobal.workspace.createMany({data:[{id:workspaceId,tenantId,name:"Trace"},
    {id:otherWorkspace,tenantId,name:"Other trace"},{id:foreignWorkspace,tenantId:otherTenant,name:"Foreign trace"}]});
  await prismaGlobal.apiToken.createMany({data:[{token,tenantId,workspaceId},{token:otherToken,tenantId,workspaceId:otherWorkspace},
    {token:foreignToken,tenantId:otherTenant,workspaceId:foreignWorkspace}]});
});
after(async()=>{
  await prismaGlobal.helpdeskSession.deleteMany({where:{tenantId:{in:[tenantId,otherTenant]}}});
  await prismaGlobal.apiToken.deleteMany({where:{tenantId:{in:[tenantId,otherTenant]}}});
  await prismaGlobal.workspace.deleteMany({where:{tenantId:{in:[tenantId,otherTenant]}}});
  await prismaGlobal.tenant.deleteMany({where:{id:{in:[tenantId,otherTenant]}}});
  await closePrismaResources();
});

test("existing POST and GET persist and restore a trace only as client reported",async()=>{
  const created=await request.post("/api/helpdesk/session").set("Authorization",auth()).send(body(trace));
  assert.equal(created.status,201);
  const stored=await prismaGlobal.helpdeskSession.findUniqueOrThrow({where:{id:created.body.data.id}});
  assert.deepEqual((stored.metadata as any).responseTrace,trace);
  assert.equal(stored.tenantId,tenantId);assert.equal(stored.workspaceId,workspaceId);
  const read=await request.get("/api/helpdesk/sessions").set("Authorization",auth());
  assert.equal(read.status,200);
  const interaction=read.body.data.groups.flatMap((group:any)=>group.interactions).find((row:any)=>row.id===stored.id);
  assert.deepEqual(interaction.responseTrace,{assurance:"client_reported",trace});
  assert.ok(interaction.createdAt);
});

test("API rejects malformed, self-certified and incompatible trace before writing",async()=>{
  const before=await prismaGlobal.helpdeskSession.count({where:{tenantId,workspaceId}});
  for (const invalid of [{...trace,serverVerified:true},{...trace,origin:"help_dictionary"},
    {...trace,version:"future"},{...trace,fallback:false},{...trace,message:"must not be trace"}]) {
    const response=await request.post("/api/helpdesk/session").set("Authorization",auth()).send(body(invalid));
    assert.equal(response.status,400);
  }
  assert.equal(await prismaGlobal.helpdeskSession.count({where:{tenantId,workspaceId}}),before);
});

test("used and unknown fallback survive storage; client metadata cannot certify the returned view",async()=>{
  for (const fallback of ["used","unknown"] as const) {
    const reported:HelpdeskResponseTraceV1={...trace,resolver:"launcher_decision_v1",origin:"unknown",
      policyVersion:null,intentId:null,fallback,decisionKind:fallback==="used"?"contextual_fallback":"unclassified"};
    const payload=body(reported);
    const created=await request.post("/api/helpdesk/session").set("Authorization",auth()).send({
      ...payload,metadata:{...payload.metadata,assurance:"server_verified"},
    });
    assert.equal(created.status,201);
    const read=await request.get("/api/helpdesk/sessions").set("Authorization",auth());
    const interaction=read.body.data.groups.flatMap((group:any)=>group.interactions).find((row:any)=>row.id===created.body.data.id);
    assert.deepEqual(interaction.responseTrace,{assurance:"client_reported",trace:reported});
  }
});

test("legacy metadata is accepted but source string and false flag cannot certify an origin",async()=>{
  const payload={...body(undefined),metadata:{source:"tutor_contract_v1",fallbackUsed:false}};
  const created=await request.post("/api/helpdesk/session").set("Authorization",auth()).send(payload);
  assert.equal(created.status,201);
  const read=await request.get("/api/helpdesk/sessions").set("Authorization",auth());
  const interaction=read.body.data.groups.flatMap((group:any)=>group.interactions).find((row:any)=>row.id===created.body.data.id);
  assert.deepEqual(interaction.responseTrace,{assurance:"unavailable",trace:null});
});

test("existing auth and write scope stay enforced; default reads isolate workspace and tenant",async()=>{
  assert.equal((await request.post("/api/helpdesk/session").send(body(trace))).status,401);
  for (const identity of [{tenantId:otherTenant},{workspaceId:otherWorkspace}]) {
    const response=await request.post("/api/helpdesk/session").set("Authorization",auth()).send({...body(trace),...identity});
    assert.equal(response.status,403);
  }
  for (const value of [otherToken,foreignToken]) {
    const response=await request.get("/api/helpdesk/sessions").set("Authorization",auth(value));
    assert.equal(response.status,200);assert.equal(response.body.data.totalSessions,0);
  }
});
