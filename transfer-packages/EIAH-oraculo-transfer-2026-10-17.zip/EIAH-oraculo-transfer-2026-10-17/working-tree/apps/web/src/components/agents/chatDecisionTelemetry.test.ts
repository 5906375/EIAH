import test from "node:test";
import assert from "node:assert/strict";
import { readHelpdeskResponseTrace } from "@eiah/contracts";
import { buildEiahTutorResponseTrace } from "./eiahTutorContracts";
import { resolveEiahDecision } from "./chatLauncherEngine";
import { buildLauncherHelpdeskSessionPayload, buildLauncherPersistenceTelemetry } from "./chatDecisionTelemetry";

const input = {
  tenantId:"synthetic",workspaceId:"synthetic",message:"Pergunta sintética",response:"Resposta sintética",
  intentResult:{intent:"help" as const,confidence:1},rolloutStage:"test",threadKey:"synthetic",activeAgentId:"EIAH",
  activeAgentName:"EIAH",chatRuntimeReadiness:"ready",chatRuntimeResolver:"test",chatRuntimeMissingFields:[],
  attachmentOffered:false,attachmentKinds:[],attachmentIntakeModes:[],attachmentAnalysisModes:[],attachmentUsed:false,
};

test("real tutor decision transports agent policy and trace through existing payload metadata", () => {
  const decision = resolveEiahDecision({ input:"Explicar agentes",routeIntent:"help",eiahMode:"help",
    agentProfile:null,catalogAgents:[],intentUnknown:false,accessContext:{tenantId:"synthetic",workspaceId:"synthetic"} });
  assert.equal(decision.responseTrace?.origin,"tutor_contract");
  assert.equal(decision.responseTrace?.policyVersion,"1.0.0");
  const telemetry = buildLauncherPersistenceTelemetry({decision});
  const payload = buildLauncherHelpdeskSessionPayload({...input,responseTrace:telemetry.responseTrace});
  assert.ok(payload); // Traced local successes must not disappear just because there is no run/fallback.
  assert.equal(readHelpdeskResponseTrace(payload.metadata).assurance,"client_reported");
  assert.deepEqual(readHelpdeskResponseTrace(payload.metadata).trace,decision.responseTrace);
  assert.ok(!JSON.stringify(decision.responseTrace).includes(input.message));
});

test("contract fallback and policy blocks are distinguished by the agent contract", () => {
  assert.equal(buildEiahTutorResponseTrace("platform_overview_fallback").fallback,"used");
  assert.equal(buildEiahTutorResponseTrace("policy_blocked_workspace").fallback,"not_used");
});

test("dictionary branch is not labelled as Tutor contract; real unmatched input reports fallback", () => {
  const resolve = (value:string) => resolveEiahDecision({input:value,routeIntent:"help",eiahMode:"help",
    agentProfile:null,catalogAgents:[],intentUnknown:false,accessContext:{tenantId:"synthetic",workspaceId:"synthetic"}});
  const dictionary=resolve("como ler os cards dos agentes?");
  assert.equal(dictionary.responseTrace?.origin,"help_dictionary");
  assert.equal(dictionary.responseTrace?.policyVersion,null);
  const unresolved=resolve("xyzabc");
  assert.equal(unresolved.kind,"contextual_fallback");
  const telemetry=buildLauncherPersistenceTelemetry({decision:unresolved});
  assert.equal(telemetry.responseTrace.origin,"unknown");
  assert.equal(telemetry.responseTrace.fallback,"used");
});

test("known fallback records used with unknown origin; absent flag remains unknown", () => {
  const telemetry = buildLauncherPersistenceTelemetry({decision:{kind:"contextual_fallback",presentationRouteIntent:"help"}});
  const fallback = buildLauncherHelpdeskSessionPayload({...input,responseTrace:telemetry.responseTrace,fallbackUsed:true});
  assert.equal(readHelpdeskResponseTrace(fallback?.metadata).trace?.fallback,"used");
  assert.equal(readHelpdeskResponseTrace(fallback?.metadata).trace?.origin,"unknown");
  const old = buildLauncherHelpdeskSessionPayload({...input,persist:true});
  assert.equal(readHelpdeskResponseTrace(old?.metadata).trace?.fallback,"unknown");
  const explicit = buildLauncherHelpdeskSessionPayload({...input,persist:true,fallbackUsed:false});
  assert.equal(readHelpdeskResponseTrace(explicit?.metadata).trace?.fallback,"not_used");
  const uninstrumented = buildLauncherPersistenceTelemetry({decision:{kind:"clarification",presentationRouteIntent:"help"}});
  assert.equal(uninstrumented.responseTrace.fallback,"unknown");
  assert.equal(buildLauncherHelpdeskSessionPayload({...input,responseTrace:uninstrumented.responseTrace}),null);
  const persistedUnknown = buildLauncherHelpdeskSessionPayload({...input,persist:true,responseTrace:uninstrumented.responseTrace,
    fallbackUsed:uninstrumented.fallbackUsed});
  assert.equal(readHelpdeskResponseTrace(persistedUnknown?.metadata).trace?.fallback,"unknown");
  assert.equal(buildLauncherHelpdeskSessionPayload(input),null);
});
