import test from "node:test";
import assert from "node:assert/strict";

import {
  buildImobFrontdoorStatePresentation,
  buildAssistantMessageDedupeKey,
  dedupeRunMessages,
  normalizeImobAccessGateErrorPresentation,
  buildPersistedImobChatMessageMetadata,
  mapStoredMessageToChat,
} from "./chat";
import { ApiError } from "@/lib/api";

test("dedupeKey da apresentação preserva identidade no histórico sem alterar metadata da API", () => {
  const makeMessage = (key: string, id: string) => ({
    id, role: "assistant" as const, text: "Continue pelos campos abaixo.",
    presentationDedupeKey: key,
    presentationMetadata: { choiceStyle: "inline" as const },
  });
  const first = makeMessage("property.create:collecting", "first");
  const metadata = buildPersistedImobChatMessageMetadata(first);
  assert.deepEqual(metadata.presentationMetadata, { choiceStyle: "inline" });
  assert.equal(metadata.presentationDedupeKey, "property.create:collecting");
  const restored = mapStoredMessageToChat({
    id: "restored", conversationId: "synthetic", role: "assistant",
    content: first.text, metadata, createdAt: "2026-10-17T00:00:00Z",
  });
  assert.equal(dedupeRunMessages([first, restored]).length, 1);
  assert.equal(dedupeRunMessages([first, makeMessage("property.create:review", "distinct")]).length, 2);
});

test("dedupe mantém compatibilidade com chave legada em metadata persistida", () => {
  const restore = (id: string) => mapStoredMessageToChat({
    id, conversationId: "synthetic", role: "assistant", content: "Continuar",
    metadata: { presentationMetadata: { dedupeKey: "legacy:key" } },
    createdAt: "2026-10-17T00:00:00Z",
  });
  assert.equal(dedupeRunMessages([restore("one"), restore("two")]).length, 1);
});

function renderImobFrontdoorPresentationForTest(
  presentation: ReturnType<typeof buildImobFrontdoorStatePresentation>,
) {
  const rows = [
    `message:${presentation.text}`,
    `card.type:${presentation.card.type}`,
    `card.title:${presentation.card.title}`,
    ...presentation.card.lines.map((line) => `card.line:${line}`),
    ...(presentation.card.ctas ?? []).map((cta) => [
      `cta.label:${cta.label}`,
      cta.href ? `cta.href:${cta.href}` : null,
      cta.nextMessage ? `cta.nextMessage:${cta.nextMessage}` : null,
    ].filter(Boolean).join("|")),
    presentation.card.risk?.reason ? `risk.reason:${presentation.card.risk.reason}` : null,
  ];

  return rows.filter((row): row is string => Boolean(row)).join("\n");
}

test("dedupeRunMessages colapsa duplicata assistente legado sem runId inicial", () => {
  const dedupeKey = buildAssistantMessageDedupeKey({
    action: "realestate.register_property",
    presentationDedupeKey: "property.create:collecting",
    text: "Preencha os campos abaixo para continuar o cadastro do imóvel.",
    threadId: "thread-captacao-1",
  });

  const items = dedupeRunMessages([
    {
      id: "assistant-plan",
      role: "assistant",
      text: "Preencha os campos abaixo para continuar o cadastro do imóvel.",
      assistantDedupeKey: dedupeKey,
      thread: { id: "thread-captacao-1", label: "Captação", status: "active" },
      card: { type: "queue", title: "Preparando", lines: [] },
    } as any,
    {
      id: "assistant-terminal",
      role: "assistant",
      text: "Preencha os campos abaixo para continuar o cadastro do imóvel.",
      assistantDedupeKey: dedupeKey,
      thread: { id: "thread-captacao-1", label: "Captação", status: "done" },
      card: { type: "queue", title: "Concluído", lines: [], runId: "run-123" },
    } as any,
  ]);

  assert.equal(items.length, 1);
  assert.equal(items[0]?.id, "assistant-terminal");
  assert.equal(items[0]?.card?.runId, "run-123");
});

test("dedupeRunMessages preserva mensagens assistente semanticamente distintas", () => {
  const first = buildAssistantMessageDedupeKey({
    action: "realestate.register_property",
    presentationDedupeKey: "property.create:collecting",
    text: "Preencha os campos abaixo para continuar o cadastro do imóvel.",
    threadId: "thread-captacao-1",
  });
  const second = buildAssistantMessageDedupeKey({
    action: "realestate.register_property",
    presentationDedupeKey: "property.create:ready_for_review",
    text: "Atualizei o cadastro do imóvel. Continue pelos campos pendentes abaixo.",
    threadId: "thread-captacao-1",
  });

  const items = dedupeRunMessages([
    {
      id: "assistant-1",
      role: "assistant",
      text: "Preencha os campos abaixo para continuar o cadastro do imóvel.",
      assistantDedupeKey: first,
      thread: { id: "thread-captacao-1", label: "Captação", status: "active" },
    } as any,
    {
      id: "assistant-2",
      role: "assistant",
      text: "Atualizei o cadastro do imóvel. Continue pelos campos pendentes abaixo.",
      assistantDedupeKey: second,
      thread: { id: "thread-captacao-1", label: "Captação", status: "done" },
      card: { type: "queue", title: "Concluído", lines: [], runId: "run-456" },
    } as any,
  ]);

  assert.equal(items.length, 2);
  assert.equal(items[0]?.id, "assistant-1");
  assert.equal(items[1]?.id, "assistant-2");
});

test("dedupeRunMessages mantém fallback por runId para started e terminal do mesmo run", () => {
  const items = dedupeRunMessages([
    {
      id: "assistant-started",
      role: "assistant",
      text: "Atualizando progresso em tempo real.",
      thread: { id: "thread-captacao-1", label: "Captação", status: "active" },
      card: { type: "queue", title: "Em andamento", lines: [], runId: "run-789" },
    } as any,
    {
      id: "assistant-terminal",
      role: "assistant",
      text: "Atualizei o cadastro do imóvel. Continue pelos campos pendentes abaixo.",
      thread: { id: "thread-captacao-1", label: "Captação", status: "done" },
      card: { type: "queue", title: "Concluído", lines: [], runId: "run-789" },
    } as any,
  ]);

  assert.equal(items.length, 1);
  assert.equal(items[0]?.id, "assistant-terminal");
});

test("normalizeImobAccessGateErrorPresentation preserves backend message, reasonCode and CTA", () => {
  const error = new ApiError(403, "Forbidden", {
    ok: false,
    error: {
      message: "IMOB não está habilitado neste workspace.",
      reasonCode: "IMOB_ENTITLEMENT_MISSING",
      cta: {
        type: "INSTALL",
        label: "Instalar IMOB",
        target: "/app/marketplace/imob",
      },
      details: {
        entitlementRequired: "IMOB_ACTIVE_INSTALLATION",
        installationStatus: "missing",
      },
    },
  });

  const presentation = normalizeImobAccessGateErrorPresentation(error);

  assert.equal(presentation.text, "IMOB não está habilitado neste workspace.");
  assert.ok(presentation.card.lines.includes("Código: IMOB_ENTITLEMENT_MISSING"));
  assert.deepEqual(presentation.card.ctas, [
    {
      id: "imob-access-gate-IMOB_ENTITLEMENT_MISSING",
      label: "Instalar IMOB",
      href: "/app/marketplace/imob",
      kind: "primary",
    },
  ]);
});

test("normalizeImobAccessGateErrorPresentation does not invent CTA when backend omits it", () => {
  const error = new ApiError(403, "Forbidden", {
    ok: false,
    error: {
      message: "Você não possui permissão para usar este recurso do IMOB neste workspace.",
      reasonCode: "IMOB_PERMISSION_DENIED",
    },
  });

  const presentation = normalizeImobAccessGateErrorPresentation(error);

  assert.equal(presentation.text, "Você não possui permissão para usar este recurso do IMOB neste workspace.");
  assert.ok(presentation.card.lines.includes("Código: IMOB_PERMISSION_DENIED"));
  assert.equal(presentation.card.ctas, undefined);
});

test("normalizeImobAccessGateErrorPresentation uses safe fallback without backend message", () => {
  const error = new ApiError(403, "Forbidden", {
    ok: false,
    error: {
      reasonCode: "IMOB_INSTALLATION_INACTIVE",
      cta: {
        label: "",
        target: "/app/marketplace/imob",
      },
    },
  });

  const presentation = normalizeImobAccessGateErrorPresentation(error);

  assert.equal(presentation.text, "Não foi possível concluir esta ação neste workspace.");
  assert.ok(presentation.card.lines.includes("Código: IMOB_INSTALLATION_INACTIVE"));
  assert.equal(presentation.card.ctas, undefined);
});

test("buildImobFrontdoorStatePresentation renders loading without CTA", () => {
  const presentation = buildImobFrontdoorStatePresentation({ kind: "loading" });

  assert.equal(presentation.text, "Carregando o contexto IMOB...");
  assert.equal(presentation.card.type, "queue");
  assert.equal(presentation.card.queue?.status, "loading");
  assert.equal(presentation.card.ctas, undefined);
});

test("buildImobFrontdoorStatePresentation renders empty front door without invented next step", () => {
  const presentation = buildImobFrontdoorStatePresentation({ kind: "empty" });

  assert.equal(presentation.text, "Ainda não há uma conversa IMOB iniciada neste workspace.");
  assert.equal(presentation.card.type, "action");
  assert.match(presentation.card.lines.join("\n"), /O próximo passo será decidido pelo agente/);
  assert.equal(presentation.card.ctas, undefined);
});

test("buildImobFrontdoorStatePresentation renders generic structured error without CTA", () => {
  const error = new ApiError(500, "Internal Server Error", {
    ok: false,
    error: {
      message: "Falha temporária ao consultar o contexto IMOB.",
      reasonCode: "IMOB_CONTEXT_QUERY_FAILED",
      cta: {
        label: "Não deve aparecer",
        target: "/app/imob",
      },
    },
  });

  const presentation = buildImobFrontdoorStatePresentation({ kind: "error", error });

  assert.equal(presentation.text, "Falha temporária ao consultar o contexto IMOB.");
  assert.equal(presentation.card.type, "risk");
  assert.ok(presentation.card.lines.includes("Código: IMOB_CONTEXT_QUERY_FAILED"));
  assert.equal(presentation.card.ctas, undefined);
});

test("buildImobFrontdoorStatePresentation preserves F0.1 entitlement CTA when backend sends it", () => {
  const error = new ApiError(403, "Forbidden", {
    ok: false,
    error: {
      message: "IMOB não está habilitado neste workspace.",
      reasonCode: "IMOB_ENTITLEMENT_MISSING",
      cta: {
        label: "Instalar IMOB",
        target: "/app/marketplace/imob",
      },
    },
  });

  const presentation = buildImobFrontdoorStatePresentation({ kind: "entitlement", error });

  assert.equal(presentation.text, "IMOB não está habilitado neste workspace.");
  assert.deepEqual(presentation.card.ctas, [
    {
      id: "imob-access-gate-IMOB_ENTITLEMENT_MISSING",
      label: "Instalar IMOB",
      href: "/app/marketplace/imob",
      kind: "primary",
    },
  ]);
});

test("buildImobFrontdoorStatePresentation preserves entitlement without invented CTA", () => {
  const error = new ApiError(403, "Forbidden", {
    ok: false,
    error: {
      message: "Você não possui permissão para usar este recurso do IMOB neste workspace.",
      reasonCode: "IMOB_PERMISSION_DENIED",
    },
  });

  const presentation = buildImobFrontdoorStatePresentation({ kind: "entitlement", error });

  assert.equal(presentation.text, "Você não possui permissão para usar este recurso do IMOB neste workspace.");
  assert.equal(presentation.card.ctas, undefined);
});

test("buildImobFrontdoorStatePresentation fails closed for unknown state", () => {
  const presentation = buildImobFrontdoorStatePresentation({ kind: "unexpected_state" });

  assert.equal(presentation.text, "Não foi possível determinar o próximo estado do atendimento IMOB.");
  assert.equal(presentation.card.type, "risk");
  assert.equal(presentation.card.risk?.reason, "IMOB_FRONTDOOR_UNKNOWN_STATE");
  assert.equal(presentation.card.ctas, undefined);
});

test("IMOB front door UX rendering evidence covers F0.1 and F0.2 states", () => {
  const entitlementWithCta = renderImobFrontdoorPresentationForTest(
    buildImobFrontdoorStatePresentation({
      kind: "entitlement",
      error: new ApiError(403, "Forbidden", {
        ok: false,
        error: {
          message: "IMOB ainda não está instalado neste workspace.",
          reasonCode: "IMOB_NOT_INSTALLED",
          cta: {
            type: "link",
            label: "Instalar IMOB",
            target: "/app/marketplace/imob",
          },
        },
      }),
    }),
  );

  assert.match(entitlementWithCta, /message:IMOB ainda não está instalado neste workspace\./);
  assert.match(entitlementWithCta, /card.line:Código: IMOB_NOT_INSTALLED/);
  assert.match(entitlementWithCta, /cta.label:Instalar IMOB/);
  assert.match(entitlementWithCta, /cta.href:\/app\/marketplace\/imob/);

  const entitlementWithoutCta = renderImobFrontdoorPresentationForTest(
    buildImobFrontdoorStatePresentation({
      kind: "entitlement",
      error: new ApiError(403, "Forbidden", {
        ok: false,
        error: {
          message: "Você não possui permissão para usar este recurso do IMOB neste workspace.",
          reasonCode: "IMOB_PERMISSION_DENIED",
        },
      }),
    }),
  );

  assert.match(entitlementWithoutCta, /message:Você não possui permissão/);
  assert.match(entitlementWithoutCta, /card.line:Código: IMOB_PERMISSION_DENIED/);
  assert.doesNotMatch(entitlementWithoutCta, /cta\.label:/);
  assert.doesNotMatch(entitlementWithoutCta, /Instalar IMOB/);

  const loading = renderImobFrontdoorPresentationForTest(
    buildImobFrontdoorStatePresentation({ kind: "loading" }),
  );

  assert.match(loading, /message:Carregando o contexto IMOB/);
  assert.match(loading, /card.title:Contexto IMOB em carregamento/);
  assert.doesNotMatch(loading, /cta\.label:/);
  assert.doesNotMatch(loading, /Instalar IMOB/);

  const empty = renderImobFrontdoorPresentationForTest(
    buildImobFrontdoorStatePresentation({ kind: "empty" }),
  );

  assert.match(empty, /message:Ainda não há uma conversa IMOB iniciada neste workspace\./);
  assert.match(empty, /card.title:Front door IMOB pronto/);
  assert.doesNotMatch(empty, /cta\.label:/);
  assert.doesNotMatch(empty, /IMOB_NOT_INSTALLED/);

  const genericError = renderImobFrontdoorPresentationForTest(
    buildImobFrontdoorStatePresentation({
      kind: "error",
      error: new ApiError(500, "Internal Server Error", {
        ok: false,
        error: {
          message: "Falha temporária ao consultar o contexto IMOB.",
          reasonCode: "IMOB_CONTEXT_QUERY_FAILED",
          details: {
            stack: "Error: sensitive stack should not render",
            token: "secret-token-should-not-render",
          },
        },
      }),
    }),
  );

  assert.match(genericError, /message:Falha temporária ao consultar o contexto IMOB\./);
  assert.match(genericError, /card.line:Código: IMOB_CONTEXT_QUERY_FAILED/);
  assert.doesNotMatch(genericError, /sensitive stack/);
  assert.doesNotMatch(genericError, /secret-token/);
  assert.doesNotMatch(genericError, /cta\.label:/);

  const unknownFallback = renderImobFrontdoorPresentationForTest(
    buildImobFrontdoorStatePresentation({ kind: "unknown_runtime_state" }),
  );

  assert.match(unknownFallback, /message:Não foi possível determinar o próximo estado/);
  assert.match(unknownFallback, /card.line:O atendimento foi pausado em modo fail-closed\./);
  assert.match(unknownFallback, /risk.reason:IMOB_FRONTDOOR_UNKNOWN_STATE/);
  assert.doesNotMatch(unknownFallback, /cta\.label:/);
});
