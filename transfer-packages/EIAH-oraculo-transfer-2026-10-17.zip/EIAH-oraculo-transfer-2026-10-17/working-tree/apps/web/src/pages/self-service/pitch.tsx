import React, { useMemo } from "react";
import { Navigate } from "react-router-dom";
import AgentFormShell from "./components/AgentFormShell";
import SelfServiceNav from "./components/SelfServiceNav";
import { getAgentConfigBySlug, isGenericAgentConfig } from "./config";

type FormValues = Record<string, string>;

// Keep the shell's reset-effect dependency stable across form updates.
const preserveValueKeysOnInitialChange: string[] = [];

export default function SelfServicePitchPage() {
  const config = getAgentConfigBySlug("pitch");
  if (!config || !isGenericAgentConfig(config)) {
    return <Navigate to="/self-service" replace />;
  }

  const genericConfig = config;

  const initialValues = useMemo<FormValues>(() => {
    const entries = genericConfig.fields.map((field) => [field.key, ""]);
    return Object.fromEntries(entries);
  }, [genericConfig.fields]);

  return (
    <div className="space-y-6">
      <SelfServiceNav currentSlug={genericConfig.slug} />
      <AgentFormShell<FormValues>
        agentId={genericConfig.agentId}
        title={genericConfig.title}
        description={genericConfig.description}
        initialValues={initialValues}
        preserveValueKeysOnInitialChange={preserveValueKeysOnInitialChange}
        buildRequest={(vals) => genericConfig.buildPrompt(vals)}
      >
        {({ values: formValues, setValue }) => (
          <div className="space-y-4">
            {genericConfig.fields.map((field) => {
              const type = field.type ?? "textarea";
              const value = formValues[field.key] ?? "";

              if (type === "text") {
                return (
                  <label key={field.key} className="flex flex-col gap-2 text-sm text-foreground">
                    {field.label}
                    <input
                      type="text"
                      value={value}
                      onChange={(e) => setValue(field.key as keyof FormValues, e.target.value)}
                      placeholder={field.placeholder}
                      className="rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-foreground focus:border-accent focus:outline-none"
                    />
                    {field.helper && <span className="text-xs text-muted-foreground">{field.helper}</span>}
                  </label>
                );
              }

              return (
                <label key={field.key} className="flex flex-col gap-2 text-sm text-foreground">
                  {field.label}
                  <textarea
                    value={value}
                    onChange={(e) => setValue(field.key as keyof FormValues, e.target.value)}
                    placeholder={field.placeholder}
                    rows={field.rows ?? 3}
                    className="rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-foreground focus:border-accent focus:outline-none"
                  />
                  {field.helper && <span className="text-xs text-muted-foreground">{field.helper}</span>}
                </label>
              );
            })}
          </div>
        )}
      </AgentFormShell>
    </div>
  );
}
