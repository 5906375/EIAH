import type { HelpdeskContractCoverageResponse, HelpdeskCoverageMetrics } from "@/lib/api";

const count = (value: unknown): number | null =>
  typeof value === "number" && Number.isSafeInteger(value) && value >= 0 ? value : null;
const percent = (value: unknown): number | null =>
  typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 100 ? value : null;

/** Availability checks only: rates are never calculated or inferred in the UI. */
export function normalizeHelpdeskCoverage(data: HelpdeskContractCoverageResponse): HelpdeskContractCoverageResponse {
  if (!data?.summary || !data.window || data.window.timezone !== "UTC" ||
      !Array.isArray(data.byWorkspace) || !Array.isArray(data.timeseries)) {
    throw new Error("Contrato de cobertura indisponível ou incompatível (recorte UTC não confirmado).");
  }
  const assurance = data.measurement?.unit === "registered_interaction" && (data.measurement?.assurance === "server_verified" || data.measurement?.assurance === "client_reported")
    ? data.measurement.assurance : "unavailable";
  const status = data.measurement?.unit === "registered_interaction" && ["complete", "incomplete", "empty", "unavailable"].some(value => value === data.measurement?.status)
    ? data.measurement.status : "unavailable";
  const measurement: HelpdeskContractCoverageResponse["measurement"] = {
    unit: "registered_interaction", status, assurance,
    reason: typeof data.measurement?.reason === "string" && data.measurement.reason.trim()
      ? data.measurement.reason.trim() : null,
  };
  const usable = status === "complete" && assurance === "server_verified" && data.measurement?.unit === "registered_interaction";
  const normalize = (row: HelpdeskCoverageMetrics): HelpdeskCoverageMetrics => {
    if (status === "unavailable") return {
      totalEvents:null,contractEvents:null,fallbackEvents:null,netContractEvents:null,unknownSourceEvents:null,unknownFallbackEvents:null,
      contractCoveragePct:null,fallbackRatePct:null,netContractCoveragePct:null,
    };
    const verified=assurance === "server_verified" || (status === "empty" && count(row.totalEvents) === 0);
    const totalEvents=count(row.totalEvents), contractEvents=verified ? count(row.contractEvents) : null, fallbackEvents=verified ? count(row.fallbackEvents) : null;
    const netContractEvents=verified ? count(row.netContractEvents) : null, unknownSourceEvents=verified ? count(row.unknownSourceEvents) : null, unknownFallbackEvents=verified ? count(row.unknownFallbackEvents) : null;
    if (status === "empty" && [totalEvents,contractEvents,fallbackEvents,netContractEvents,unknownSourceEvents,unknownFallbackEvents].some(value=>value!==null&&value!==0)) {
      throw new Error("Medição vazia contém contagens não vazias.");
    }
    if (totalEvents !== null && (
      [contractEvents,fallbackEvents,netContractEvents,unknownSourceEvents,unknownFallbackEvents].some(value=>value!==null&&value>totalEvents) ||
      (contractEvents!==null&&unknownSourceEvents!==null&&contractEvents+unknownSourceEvents>totalEvents) ||
      (fallbackEvents!==null&&unknownFallbackEvents!==null&&fallbackEvents+unknownFallbackEvents>totalEvents) ||
      (netContractEvents!==null&&contractEvents!==null&&netContractEvents>contractEvents) ||
      (netContractEvents!==null&&fallbackEvents!==null&&netContractEvents>totalEvents-fallbackEvents)
    )) throw new Error("Contagens de cobertura incompatíveis com o total de interações registradas.");
    const nonempty = usable && totalEvents !== null && totalEvents > 0;
    return {
      totalEvents, contractEvents, fallbackEvents, netContractEvents, unknownSourceEvents, unknownFallbackEvents,
      contractCoveragePct: nonempty && contractEvents !== null && unknownSourceEvents === 0 ? percent(row.contractCoveragePct) : null,
      fallbackRatePct: nonempty && fallbackEvents !== null && unknownFallbackEvents === 0 ? percent(row.fallbackRatePct) : null,
      netContractCoveragePct: nonempty && netContractEvents !== null && unknownSourceEvents === 0 && unknownFallbackEvents === 0
        ? percent(row.netContractCoveragePct) : null,
    };
  };
  return {
    ...data, measurement, summary: normalize(data.summary),
    byWorkspace: data.byWorkspace.map(row => ({ ...row, ...normalize(row) })),
    timeseries: data.timeseries.map(row => ({ ...row, ...normalize(row) })),
  };
}

export const formatCoverageCount = (value: number | null | undefined): string =>
  count(value) === null ? "Indisponível" : String(value);
export const formatCoveragePercent = (value: number | null | undefined): string => {
  const valid = percent(value);
  return valid === null ? "Indisponível" : `${Number(valid.toFixed(2))}%`;
};

export function describeCoverageMeasurement(data: HelpdeskContractCoverageResponse): string {
  const assurance = data.measurement.assurance === "client_reported"
    ? "Origem reportada pelo cliente; sem comprovação independente no servidor."
    : data.measurement.assurance === "server_verified" ? "Origem verificada no servidor."
      : "Comprovação de origem indisponível.";
  const status = {
    complete: "Consulta completa das interações registradas.", incomplete: "Medição incompleta.",
    empty: "Sem interações registradas no período.", unavailable: "Medição indisponível.",
  }[data.measurement.status];
  return [status, assurance, "Taxas sem dados suficientes são indisponíveis.", data.measurement.reason].filter(Boolean).join(" ");
}

export function buildCoverageCsv(input: HelpdeskContractCoverageResponse): string {
  const data=normalizeHelpdeskCoverage(input);
  const header = ["scope","dateFrom","dateTo","granularity","timezone","date","workspaceId","workspaceName",
    "unit","measurementStatus","assurance","reason","totalEvents","contractEvents","fallbackEvents","netContractEvents",
    "unknownSourceEvents","unknownFallbackEvents","contractCoveragePct","fallbackRatePct","netContractCoveragePct"];
  const cells = (scope: string, row: HelpdeskCoverageMetrics, workspaceId: string, name = "", date = "") => [
    scope,data.window.dateFrom,data.window.dateTo,data.window.granularity,data.window.timezone,date,workspaceId,name,
    data.measurement.unit,data.measurement.status,data.measurement.assurance,data.measurement.reason,
    row.totalEvents,row.contractEvents,row.fallbackEvents,row.netContractEvents,row.unknownSourceEvents,row.unknownFallbackEvents,
    row.contractCoveragePct,row.fallbackRatePct,row.netContractCoveragePct,
  ];
  const rows = [header,cells("summary",data.summary,data.filters.workspaceId),
    ...data.byWorkspace.map(row=>cells("workspace",row,row.workspaceId,row.workspaceName?.trim() || row.workspaceId)),
    ...data.timeseries.map(row=>cells("timeseries",row,data.filters.workspaceId,"",row.date))];
  // Empty cells mean unavailable; literal zero remains zero. Quality travels with every row.
  return rows.map(row=>row.map(value=>`"${String(value ?? "").replace(/"/g,'""')}"`).join(",")).join("\n");
}

export const escapeCoverageHtml = (value: string): string => value.replace(/[&<>"']/g, char =>
  ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char] ?? char));
