import test from "node:test";
import assert from "node:assert/strict";
import { resolveImobAccessGateCopy } from "./accessGateCatalog";

test("IMOB preserva os motivos conhecidos e a mensagem recebida da API", () => {
  const cases = [
    ["IMOB_ENTITLEMENT_MISSING", "Acesso indisponível"],
    ["IMOB_INSTALLATION_INACTIVE", "Instalação inativa"],
    ["IMOB_PERMISSION_DENIED", "Acesso restrito"],
  ];
  for (const [reasonCode, title] of cases) {
    const copy = resolveImobAccessGateCopy({ reasonCode, message: "  Mensagem do servidor  " });
    assert.deepEqual(copy, { title, body: "Mensagem do servidor" });
    assert.ok(resolveImobAccessGateCopy({ reasonCode, message: " " }).body.length > 0);
  }
});

test("IMOB trata motivo desconhecido como acesso restrito sem consultar propriedades herdadas", () => {
  const restricted = resolveImobAccessGateCopy({ reasonCode: "IMOB_PERMISSION_DENIED" });
  for (const reasonCode of ["NEW_SERVER_REASON", "toString", "constructor", "__proto__", ""]) {
    assert.deepEqual(resolveImobAccessGateCopy({ reasonCode }), restricted);
    assert.equal(resolveImobAccessGateCopy({ reasonCode, message: "Acesso bloqueado pelo servidor" }).body,
      "Acesso bloqueado pelo servidor");
  }
});

test("IMOB mantém fallback existente quando o motivo está ausente", () => {
  const missing = resolveImobAccessGateCopy({ reasonCode: "IMOB_ENTITLEMENT_MISSING" });
  for (const gate of [undefined, null, {}]) assert.deepEqual(resolveImobAccessGateCopy(gate), missing);
});
