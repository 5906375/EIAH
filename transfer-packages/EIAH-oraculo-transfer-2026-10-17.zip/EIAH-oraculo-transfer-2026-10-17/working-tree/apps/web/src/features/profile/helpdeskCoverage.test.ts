import test from "node:test";
import assert from "node:assert/strict";
import type { HelpdeskContractCoverageResponse } from "@/lib/api";
import { normalizeHelpdeskCoverage, formatCoveragePercent, formatCoverageCount, buildCoverageCsv, describeCoverageMeasurement, escapeCoverageHtml } from "./helpdeskCoverage";

function fixture(): HelpdeskContractCoverageResponse {
  const metrics={totalEvents:100,contractEvents:60,fallbackEvents:20,netContractEvents:55,unknownSourceEvents:0,unknownFallbackEvents:0,
    contractCoveragePct:60,fallbackRatePct:20,netContractCoveragePct:55};
  return {measurement:{unit:"registered_interaction",status:"complete",assurance:"server_verified",reason:null},
    window:{dateFrom:"2026-10-01",dateTo:"2026-10-17",granularity:"week",timezone:"UTC"},filters:{workspaceId:"workspace-synthetic"},
    summary:{...metrics},byWorkspace:[{...metrics,workspaceId:"workspace-synthetic"}],timeseries:[{...metrics,date:"2026-09-28"}]};
}

test("verified supplied rates are preserved without calculating or conflating overlapping fallback",()=>{
  const result=normalizeHelpdeskCoverage(fixture());
  assert.equal(result.summary.netContractCoveragePct,55);
  assert.equal(formatCoveragePercent(result.summary.contractCoveragePct),"60%");
  assert.equal(result.timeseries[0].date,"2026-09-28");
});

test("client report and missing provenance cannot become verified coverage in screen or CSV",()=>{
  const input=fixture();input.measurement.assurance="client_reported";
  const result=normalizeHelpdeskCoverage(input);
  assert.equal(result.measurement.assurance,"client_reported");
  assert.equal(result.summary.totalEvents,100);
  assert.equal(result.summary.contractEvents,null);
  assert.equal(result.summary.unknownSourceEvents,null);
  assert.equal(result.summary.contractCoveragePct,null);
  assert.equal(result.summary.fallbackRatePct,null);
  assert.equal(result.summary.netContractCoveragePct,null);
  assert.match(describeCoverageMeasurement(result),/reportada pelo cliente/);
  const lines=buildCoverageCsv(input).split("\n");
  const cells=(line:string)=>(line.match(/"(?:[^"]|"")*"/g) ?? []).map(cell=>cell.slice(1,-1).replace(/""/g,'"'));
  const header=cells(lines[0]), summary=cells(lines[1]);
  assert.equal(summary[header.indexOf("assurance")],"client_reported");
  assert.equal(summary[header.indexOf("totalEvents")],"100");
  for (const key of ["contractEvents","contractCoveragePct","fallbackRatePct","netContractCoveragePct"]) {
    assert.equal(summary[header.indexOf(key)],"");
  }
  const missing=JSON.parse(JSON.stringify(fixture()));delete missing.measurement;
  assert.equal(normalizeHelpdeskCoverage(missing).summary.totalEvents,null);
});

test("unknown origin and unknown fallback each invalidate their dependent rates",()=>{
  const input=fixture();input.summary.unknownSourceEvents=20;
  const origin=normalizeHelpdeskCoverage(input);
  assert.equal(origin.summary.contractCoveragePct,null);assert.equal(origin.summary.netContractCoveragePct,null);
  assert.equal(origin.summary.fallbackRatePct,20);
  input.summary.unknownSourceEvents=0;input.summary.unknownFallbackEvents=10;
  const fallback=normalizeHelpdeskCoverage(input);
  assert.equal(fallback.summary.contractCoveragePct,60);assert.equal(fallback.summary.fallbackRatePct,null);
  assert.equal(fallback.summary.netContractCoveragePct,null);
});

test("zero, absent data, incomplete queries and incompatible counts stay distinct",()=>{
  assert.equal(formatCoveragePercent(0),"0%");assert.equal(formatCoverageCount(0),"0");
  assert.equal(formatCoveragePercent(null),"Indisponível");assert.equal(formatCoverageCount(undefined),"Indisponível");
  const empty=fixture();empty.measurement.status="empty";empty.summary={totalEvents:0,contractEvents:0,fallbackEvents:0,netContractEvents:0,
    unknownSourceEvents:0,unknownFallbackEvents:0,contractCoveragePct:0,fallbackRatePct:0,netContractCoveragePct:0};
  empty.byWorkspace=[];empty.timeseries=[];
  assert.equal(normalizeHelpdeskCoverage(empty).summary.contractCoveragePct,null);
  assert.equal(normalizeHelpdeskCoverage(empty).summary.totalEvents,0);
  empty.measurement.assurance="unavailable";
  assert.equal(normalizeHelpdeskCoverage(empty).summary.contractEvents,0);
  assert.equal(normalizeHelpdeskCoverage(empty).summary.contractCoveragePct,null);
  const partial=fixture();partial.measurement.status="incomplete";
  assert.equal(normalizeHelpdeskCoverage(partial).summary.contractCoveragePct,null);
  const invalid=fixture();invalid.summary.contractEvents=101;
  assert.throws(()=>normalizeHelpdeskCoverage(invalid),/Contagens/);
});

test("CSV uses events, quality, workspace ID and bucket date without changing requested window",()=>{
  const csv=buildCoverageCsv(fixture());
  assert.match(csv,/"totalEvents"/);assert.ok(!csv.includes("totalSessions"));assert.ok(!csv.includes("bucketStart"));
  assert.match(csv,/"timeseries","2026-10-01","2026-10-17","week","UTC","2026-09-28"/);
  assert.match(csv,/"workspace-synthetic","workspace-synthetic"/);
  const report=fixture();report.measurement.reason='"texto" <script>';
  assert.match(buildCoverageCsv(report),/""texto"" <script>/);
  assert.equal(escapeCoverageHtml('<script>"&'),"&lt;script&gt;&quot;&amp;");
});
