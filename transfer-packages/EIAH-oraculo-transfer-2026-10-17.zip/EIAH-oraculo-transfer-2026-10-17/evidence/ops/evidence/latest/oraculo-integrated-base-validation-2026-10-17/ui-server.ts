// Local synthetic-fixture harness. Run only after test:logistica-core:integration in the dedicated DB.
import { createRequire } from "node:module";
const express = createRequire(new URL("../../../../apps/api/package.json", import.meta.url))("express");
import { randomUUID } from "node:crypto";
import { authRouter, hashPassword } from "../../../../apps/api/src/routes/auth";
import { writeFile } from "node:fs/promises";
import { prismaGlobal } from "@repo/db";
import { uploadsRouter } from "../../../../apps/api/src/routes/uploads";
import { sessionRouter } from "../../../../apps/api/src/routes/session";
import { oraculoPreparationRouter } from "../../../../apps/api/src/routes/oraculoPreparation";
const database = new URL(process.env.DATABASE_URL ?? "postgresql://unused/unused");
if (!["127.0.0.1", "localhost"].includes(database.hostname) || !database.pathname.startsWith("/eiah_logistica_core_")) throw new Error("Dedicated local test DB required");
async function main() {
  const workspaces = await prismaGlobal.workspace.findMany({ where: { name: "Other", tenantId: { startsWith: "log-core-" } }, orderBy: { createdAt: "desc" } });
  let fixture: { token: string; tenantId: string; workspaceId: string; userId?: string | null } | null = null;
  for (const workspace of workspaces) {
    const token = await prismaGlobal.apiToken.findFirst({ where: { tenantId: workspace.tenantId, workspaceId: workspace.id, revoked: false } });
    if (token && await prismaGlobal.tenantActionPolicy.count({ where: { tenantId: workspace.tenantId, workspaceId: workspace.id, allowed: true, actionName: "log.oraculo_preparation.write" } })) { fixture = { token: token.token, tenantId: token.tenantId, workspaceId: token.workspaceId, userId: token.userId }; break; }
  }
  if (!fixture) throw new Error("Run the synthetic integration test first");
  const user = await prismaGlobal.user.findUniqueOrThrow({where:{id:fixture.userId!}});
  const password = randomUUID();
  process.env.LEGACY_ACCESS_USERS_JSON = JSON.stringify([{email:user.email,passwordHash:await hashPassword(password),tenantId:fixture.tenantId,workspaceId:fixture.workspaceId,userId:fixture.userId}]);
  await writeFile("/workspace/.eiah-cloud/oraculo-integrated-browser-fixture.json", JSON.stringify({...fixture,email:user.email,password}), { mode: 0o600 });
  const app = express(); app.use(express.json());
  app.use("/api", authRouter, sessionRouter, oraculoPreparationRouter, uploadsRouter);
  app.listen(8091, "127.0.0.1", () => console.log("Synthetic preparation UI harness ready on loopback:8091"));
}
main().catch(() => { console.error("Could not start synthetic fixture harness"); process.exit(1); });
